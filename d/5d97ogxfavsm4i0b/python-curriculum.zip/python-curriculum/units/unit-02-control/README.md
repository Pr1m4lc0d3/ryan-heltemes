﻿# Unit 2 — Decisions and repetition

**Time:** 2 weeks
**Prerequisite:** Unit 1

---

## Making decisions

`if` runs a block only when a condition is true:

```python
age = 20
if age >= 18:
    print("adult")
```

`elif` and `else` chain alternatives:

```python
if age < 13:
    print("child")
elif age < 20:
    print("teenager")
else:
    print("adult")
```

Python uses **indentation** to mark blocks. Four spaces is the convention. The colon at the end of each condition opens the block; the indented lines belong to it. Inconsistent indentation is a syntax error — this is deliberate, and it makes code structure visible.

---

## Comparison and boolean operators

```python
==    # equal
!=    # not equal
<  >  <=  >=   # comparisons
and   # both true
or    # either true
not   # negate
```

Note `==` (comparison) versus `=` (assignment). Confusing them is a common early error.

Comparisons chain naturally:

```python
if 0 <= score <= 100:
    print("valid")
```

---

## Truthiness

Every value in Python is either "truthy" or "falsy". These are falsy:

```python
False
0
0.0
""        # empty string
[]        # empty list
{}        # empty dict
None
```

Everything else is truthy. So instead of:

```python
if len(items) > 0:
    ...
```

write:

```python
if items:
    ...
```

And instead of `if x == True:`, write `if x:`. Testing a boolean against `True` is redundant and often a sign the author has not understood truthiness.

---

## Repetition: while

`while` repeats as long as a condition holds:

```python
count = 0
while count < 5:
    print(count)
    count += 1
```

`count += 1` is shorthand for `count = count + 1`.

**The infinite-loop failure mode:** if the condition never becomes false, the loop never ends. The program hangs. If this happens, press `Ctrl+C` to interrupt it. Every `while` loop should have a clear path to termination — a variable that changes inside the loop and eventually makes the condition false. If you cannot point to that variable, the loop is a bug.

---

## Repetition: for

`for` iterates over a sequence:

```python
for i in range(5):
    print(i)          # 0 1 2 3 4
```

`range(5)` produces 0, 1, 2, 3, 4 — **five numbers, starting at zero.** This is the off-by-one trap. `range(1, 6)` gives 1 through 5. `range(0, 10, 2)` gives 0, 2, 4, 6, 8.

`for` is usually preferable to `while` when you are iterating a known number of times or over a collection. It is harder to get wrong.

---

## break and continue

- `break` exits the loop immediately.
- `continue` skips to the next iteration.

```python
for n in range(10):
    if n == 5:
        break       # stop entirely at 5
    if n % 2 == 0:
        continue    # skip even numbers
    print(n)        # prints 1, 3
```

Use them sparingly. A loop with many `break` and `continue` statements becomes hard to follow — often the logic can be restructured to be clearer.

---

## Nested loops

A loop inside a loop:

```python
for i in range(3):
    for j in range(3):
        print(i, j)
```

This runs the inner loop 3 times for each of the outer loop's 3 iterations — 9 total. Nested loops multiply. Two loops of 1000 each is a million iterations. Three is a billion. This is why nested loops get expensive fast, and why "does this need to be nested?" is a real question.

---

## Predicting before running

The discipline of this unit: **predict the output before you run.** Write down the value of every variable at each step. Then run and check. When your prediction is wrong, you have found a gap in your understanding — that is the valuable moment, not the failure.

---

## Structural idea for this unit

**Off-by-one errors are the most common logic bug in programming.** They come from the gap between how humans count (1, 2, 3) and how computers index (0, 1, 2). Learn to predict loop bounds by reasoning, not by trial and error.

---

## Deliverable

Three programs: a number-guessing game, a Fibonacci printer, and a prime checker. See `exercises.md`.
