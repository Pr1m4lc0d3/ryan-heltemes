﻿# The standing reading assignment

**From Unit 3 onward, part of every week is spent reading code you did not write.**

This is not busywork and it is not optional. Reading good code is the single highest-leverage habit available to a learner. You can only learn from code you are allowed to read, and reading structure teaches in a way that writing your own never quite does — because when you write, you tend to solve the problem the way you already think. When you read, you see how someone else thought.

---

## How to read a program

Do not read it like prose, top to bottom. Read it like a builder inspecting a structure:

1. **What is it for?** Read the README or the module docstring first. Know what the code is trying to do before you look at how.
2. **What are the pieces?** List the functions and classes. What does each one do? Can you tell from its name?
3. **Where does data enter and leave?** Trace one input through the program to its output. Follow it function by function.
4. **Where does it fail?** Find the error handling. What happens on bad input? Does it fail visibly?
5. **What would you change?** Every program has something. Find it. Being able to critique code is as valuable as being able to write it.

---

## What to look for

- **Names.** Do they tell the truth? Is there a function whose name hides what it really does?
- **Size.** Are the functions small? Are the files focused? Where is the biggest one, and why is it big?
- **Boundaries.** What does each function take in and give back? Could you use it without reading its body?
- **Failure.** Where are the `try`/`except` blocks? Do they catch specific errors, or everything?
- **Comments.** Do they explain *why*? Or do they just restate the code?

---

## The assignment list

These are small, readable, well-regarded programs. Read them in order — each is a little more complex than the last.

### After Unit 3 — Functions

**`textwrap` (standard library)** — the module that wraps text to a width.
Find it with `python -c "import textwrap; print(textwrap.__file__)"` and read it.
Look for: how a complex function is broken into smaller ones, and how defaults are used.

### After Unit 4 — Collections

**`collections.Counter` (standard library)** — count occurrences of things.
Read the source, or read the documentation and study the examples.
Look for: how a dictionary is the basis for a more convenient interface.

### After Unit 5 — Files and errors

**`json` (standard library)** — read and write JSON.
Look for: how errors are raised and where, and how the module decides what to catch.

### After Unit 6 — Modules

**`pathlib` (standard library)** — object-oriented file paths.
Look for: how a class models a concept (a path) and gives it behaviour.

### After Unit 7 — Objects

**`dataclasses` (standard library)** — generates boilerplate for data-holding classes.
Look for: how a class is built by code, and why `__repr__` matters.

### After Unit 8 — Testing

**`pytest`'s own test suite** — or any small project's tests.
Look for: how tests are named, what they check, and how edge cases are covered.

---

## A note on scope

Read **small** programs. A 200-line module you can understand fully teaches more than a 20,000-line framework you skim. Do not start with Django. Start with the standard library — it ships with Python, it is written by people who know what they are doing, and it is right there on your disk.

---

## What to write

For each program you read, write a short note answering:

1. What does it do?
2. What are its main pieces?
3. What did it do well?
4. What would you change?
5. What did you learn that you will use?

Keep the notes. They become a record of your growth as a programmer.
