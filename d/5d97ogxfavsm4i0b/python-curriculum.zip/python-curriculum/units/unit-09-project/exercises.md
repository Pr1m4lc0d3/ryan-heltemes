﻿# Unit 9 — Project Milestones

The project is one deliverable, but it is built in slices. Each milestone below is a checkpoint. Do not skip ahead — each depends on the last working.

---

## Milestone 1 — Design document (week 1)

Write one page:

- What the program does, in plain language.
- What the modules are, and what each one is responsible for.
- What the interfaces between them are — what each module takes in and gives back.
- What can go wrong, and how each failure is handled.

**Done when:** someone could read the design and know what to expect from the code.

---

## Milestone 2 — The smallest running version (week 1–2)

Build the smallest version that runs end to end. It may handle only one case. That is fine.

**Done when:** the program runs and produces output for at least one valid input.

---

## Milestone 3 — Core features (week 2–3)

Add the main features, one at a time. Test after each.

**Done when:** the program handles all the primary cases in the brief.

---

## Milestone 4 — Error handling (week 3)

Go back through every failure path. Bad input, missing files, invalid arguments — each must produce a clear message, not a traceback.

**Done when:** you can feed the program garbage and it responds like a tool, not a crash.

---

## Milestone 5 — Tests (week 3–4)

Write tests for each module. Include the edge cases and the error cases.

**Done when:** `pytest` passes, and you have deliberately broken the code and watched a test go red.

---

## Milestone 6 — Documentation and cleanup (week 4)

- Write the README: what it is, how to install, how to run.
- Read every function name. Fix any that lie.
- Split any file that has grown too large.
- Delete anything unused.

**Done when:** someone else can download your folder, follow the README, and run your program.

---

## Final checklist

- [ ] Runs from a clean checkout
- [ ] README explains installation and use
- [ ] Tests pass
- [ ] Bad input produces clear errors, not tracebacks
- [ ] Every name tells the truth
- [ ] No file is doing more than one job
- [ ] No dead code
