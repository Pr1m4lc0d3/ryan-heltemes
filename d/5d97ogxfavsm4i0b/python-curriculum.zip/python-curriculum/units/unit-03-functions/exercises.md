﻿# Unit 3 — Exercises

---

## Exercise 3.1 — print vs return

Predict what each line prints and what each variable holds. Then run it.

```python
def a(x):
    print(x * 2)

def b(x):
    return x * 2

p = a(5)
q = b(5)
print("p is", p)
print("q is", q)
```

**Done when:** you can explain why `p` is `None`.

---

## Exercise 3.2 — Refactor Fibonacci

Take your Fibonacci program from Unit 2 and turn it into a function `fib(n)` that **returns** a list of the first n Fibonacci numbers. Then write a small `main()` that asks for n and prints the result.

**Requirements:**
- The function returns the list. It does not print.
- The function has a docstring.
- Handle n = 0 by returning an empty list.

**Done when:** `fib(10)` returns `[0, 1, 1, 2, 3, 5, 8, 13, 21, 34]`.

---

## Exercise 3.3 — Refactor the prime checker

Turn your prime checker into a function `is_prime(n)` that returns `True` or `False`. It must not print anything.

**Requirements:**
- Handle 0, 1, and negatives by returning `False`.
- Docstring included.

**Done when:** `is_prime(7)` is `True`, `is_prime(9)` is `False`, `is_prime(1)` is `False`.

---

## Exercise 3.4 — Combine them

Write a program that asks for a number and prints all primes below it, using `is_prime` from 3.3.

**Requirements:**
- The main program prints. The helper functions do not.
- If the user enters a negative number, print a clear message and stop.

**Done when:** entering `20` prints `2 3 5 7 11 13 17 19`.

---

## Exercise 3.5 — Honest naming

Here is a function. Its name is a lie. Rename it so the name tells the truth, and then split it into two functions that each do one thing.

```python
def get_average(numbers):
    total = sum(numbers)
    numbers.clear()
    return total / len(numbers) if numbers else 0
```

**Done when:** the two functions each do exactly one thing, and each name says exactly what that thing is.

---

## Exercise 3.6 — Default arguments

Write a function `greet(name, greeting="Hello")` that returns a greeting string. Test it with and without the second argument, and with it passed as a keyword.

**Stretch:** write a function with a mutable default argument (`items=[]`), call it twice, and observe the bug. Then fix it using `None`. Explain in a comment why the first version was wrong.
