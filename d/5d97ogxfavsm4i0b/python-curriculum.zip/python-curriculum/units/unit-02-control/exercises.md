﻿# Unit 2 — Exercises

---

## Exercise 2.1 — Predict the loop

Before running anything, write down what each of these prints. Then run them and check.

```python
for i in range(5):
    print(i)
```

```python
for i in range(1, 5):
    print(i)
```

```python
for i in range(0, 10, 3):
    print(i)
```

```python
for i in range(5, 0, -1):
    print(i)
```

**Done when:** every prediction matches the output. Where it did not, explain why.

---

## Exercise 2.2 — FizzBuzz

Print the numbers 1 to 100. But for multiples of 3 print `Fizz`, for multiples of 5 print `Buzz`, and for multiples of both print `FizzBuzz`.

**Requirements:**
- Use a `for` loop and `if`/`elif`/`else`.
- Get the order of the conditions right. (Think: why must the "both" case be checked first?)

**Done when:** 15 prints `FizzBuzz`, 9 prints `Fizz`, 10 prints `Buzz`, 7 prints `7`.

---

## Exercise 2.3 — Number guessing game

The program picks a number between 1 and 100. The user guesses until they get it right. After each guess, tell them "too high" or "too low". Count the guesses and report the total when they win.

**Requirements:**
- Use `random.randint(1, 100)` to pick the number.
- Use a `while` loop.
- Give the user a way to quit (type `q`, for example) — think about how to handle that inside the loop.

**Done when:** you can play a full game and it ends correctly.

**Think about:** what happens if the user types `q`? What if they type `fifty`? Handle the first; note the second for Unit 5.

---

## Exercise 2.4 — Fibonacci

Print the first N Fibonacci numbers, where N is entered by the user.

The sequence starts 0, 1, 1, 2, 3, 5, 8, 13, ... — each number is the sum of the two before it.

**Requirements:**
- Use a loop with two tracking variables.
- Handle N = 0 (print nothing) and N = 1 (print just 0).

**Done when:** N = 10 gives `0 1 1 2 3 5 8 13 21 34`.

---

## Exercise 2.5 — Prime checker

Ask for a number and say whether it is prime.

A prime is a whole number greater than 1 with no divisors other than 1 and itself.

**Requirements:**
- Handle 0, 1, and negative numbers explicitly — they are not prime.
- Do not test divisors up to N. Test up to the square root of N. (Why is that enough? Write the reason as a comment.)

**Done when:** 2, 3, 5, 7, 11, 13 are prime; 4, 9, 15, 21 are not; 1 and 0 are not.

---

## Exercise 2.6 — Multiplication table

Ask for a number and print its multiplication table from 1 to 12, aligned in columns.

**Done when:** the output is readable and the columns line up.

**Stretch:** print a full 12×12 grid using nested loops.
