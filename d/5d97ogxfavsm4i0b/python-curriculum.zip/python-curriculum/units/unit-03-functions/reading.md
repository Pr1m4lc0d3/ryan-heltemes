﻿# Unit 3 — Reading assignment

**Read:** the `textwrap` module from the standard library.

Find it:

```bash
python -c "import textwrap; print(textwrap.__file__)"
```

Open that file in your editor. It is a few hundred lines — readable in one sitting.

---

## What to look for

1. **How a complex job is broken into small functions.** `wrap` is not one giant function; it delegates. Trace which function calls which.

2. **Defaults.** How does `wrap` decide its default width? Where is that value set, and why there?

3. **Naming.** Are the function names honest? Pick two and check that what they do matches what they are called.

4. **Docstrings.** Read the docstring of `wrap`. Does it tell you everything you need to use the function without reading its body? That is the test of a good boundary.

---

## Questions to answer

Write short answers to these, in a note:

1. What does `textwrap` do, in one sentence?
2. List three functions it defines and what each does.
3. Find one function that calls another. What is the boundary between them?
4. Is there anything you would rename? Why?
5. What did you learn that you will use in your own code?

---

## Why this module

`textwrap` is small, self-contained, and written to be read. It shows the shape of a well-structured module: a clear purpose, small functions, honest names, and docstrings that let you use it without reading the body. That is the standard to aim for.
