﻿# Unit 7 — Classes and objects

**Time:** 2 weeks
**Prerequisite:** Unit 6

---

## Why classes

A class groups **data** with the **behaviour that operates on it**. When you find yourself passing the same dictionary around and writing functions that all take it as their first argument, that is a sign a class is warranted.

A class is not always warranted. Most of the time, a function and a dict will do. Reach for a class when the data and its operations genuinely belong together and the boundary is worth enforcing.

---

## Defining a class

```python
class Dog:
    def __init__(self, name, age):
        self.name = name
        self.age = age

    def bark(self):
        return f"{self.name} says woof"

    def birthday(self):
        self.age += 1

d = Dog("Rex", 3)
print(d.bark())          # Rex says woof
d.birthday()
print(d.age)             # 4
```

- `class Dog:` defines the class. The name is capitalised by convention.
- `__init__` is the **constructor** — it runs when you create an instance.
- `self` is the instance itself. It is always the first parameter of a method.
- `d = Dog("Rex", 3)` creates an **instance**.

---

## What `self` actually is

`self` is the instance the method was called on. When you write `d.bark()`, Python calls `Dog.bark(d)` — it passes `d` as the first argument, which the method receives as `self`.

This is why `self` must be first: it is how the method knows which instance it is working with. `self.name` means "the `name` attribute of *this* instance."

Two instances have independent attributes:

```python
a = Dog("Rex", 3)
b = Dog("Fido", 5)
a.name    # "Rex"
b.name    # "Fido"
```

---

## Attributes vs local variables

```python
class Counter:
    def __init__(self):
        self.count = 0        # attribute — lives on the instance

    def increment(self):
        step = 1              # local variable — gone when the method ends
        self.count += step
```

`self.count` persists for the life of the instance. `step` exists only during the method call. Confusing the two is a common bug: if you forget `self.`, you create a local variable that vanishes.

---

## Readable representations

By default, printing an instance gives something unhelpful like `<__main__.Dog object at 0x...>`. Fix it:

```python
class Dog:
    def __init__(self, name, age):
        self.name = name
        self.age = age

    def __repr__(self):
        return f"Dog(name={self.name!r}, age={self.age!r})"

    def __str__(self):
        return f"{self.name}, {self.age} years old"
```

- `__repr__` is for developers — unambiguous, ideally showing how to recreate the object.
- `__str__` is for users — readable.

If you only define one, define `__repr__`. A class without a useful `__repr__` is harder to debug, because you cannot see what is in it.

---

## Composition before inheritance

**Composition** means one object holds another. **Inheritance** means one class extends another.

Prefer composition:

```python
class Engine:
    def start(self):
        return "vroom"

class Car:
    def __init__(self):
        self.engine = Engine()      # composition — Car HAS an Engine

    def start(self):
        return self.engine.start()
```

Inheritance (`class ElectricCar(Car):`) creates a tight coupling between the child and the parent. Changes to the parent can break the child in surprising ways. Use it only when the relationship is genuinely "is a kind of" and the parent was designed to be extended. Most of the time, composition gives you the reuse without the coupling.

---

## When not to write a class

If you have a class with only `__init__` and no methods, it is a data container — a dictionary or a `dataclass` would do.

If a class has one method, it is probably a function.

If the class is a bag of unrelated functions with no shared state, it is a module, not a class.

The temptation to make everything a class is a common beginner error, usually borrowed from languages where classes are mandatory. In Python they are not. Use one when it earns its place.

---

## Structural idea for this unit

**A class is a boundary.** It should expose the operations that make sense and hide the internals. If callers reach into its attributes and change them directly, the boundary has failed — the object can no longer guarantee its own consistency.

The convention: attributes that are internal start with an underscore (`self._balance`). This is a signal to other programmers: "this is internal, do not touch." Python does not enforce it — it trusts the reader. Which means violating it is a breach of trust, not just a mistake.

---

## Deliverable

A `Card` and `Deck` pair that shuffles and deals, extended into a simple card game. See `exercises.md`.
