﻿# Setting up Python on Linux

Everything here is done once. When you finish, you will be able to open a terminal, type `python3`, and run a program.

---

## 1. Understand what your distribution already has

Most Linux distributions ship with Python 3 already installed, because parts of the system depend on it. This is usually fine to *use*, but you should not install your own packages into it — that can break system tools.

Check what you have:

```
python3 --version
```

If you see Python 3.10 or later, you are fine to proceed. If it is older than 3.10, install a newer version (below).

---

## 2. Install or update Python

The commands depend on your distribution.

### Debian / Ubuntu / Mint

```
sudo apt update
sudo apt install python3 python3-pip python3-venv
```

Ubuntu 22.04 and later ship Python 3.10+; 24.04 ships 3.12. To get a newer version than the distribution provides, use the `deadsnakes` PPA or pyenv (below).

### Fedora

```
sudo dnf install python3 python3-pip
```

### Arch / Manjaro

```
sudo pacman -S python python-pip
```

### openSUSE

```
sudo zypper install python3 python3-pip
```

### Any distribution — pyenv (for control over versions)

If you want a specific Python version, or several side by side, install **pyenv**:

```
curl https://pyenv.run | bash
```

Follow the instructions it prints to add pyenv to your shell configuration, then:

```
pyenv install 3.12.4
pyenv global 3.12.4
```

### Verify

```
python3 --version
python3 -m pip --version
```

---

## 3. The terminal

Linux terminals are the native environment for this work. The commands:

| Task | Command |
|------|---------|
| List files | `ls` |
| Change directory | `cd folder` |
| Go up one level | `cd ..` |
| Go home | `cd ~` |
| Show current directory | `pwd` |
| Make a folder | `mkdir name` |

Move to where you want to keep your work:

```
mkdir code
cd code
```

---

## 4. Choose an editor

Install **Visual Studio Code**: https://code.visualstudio.com/ (or from your distribution's package manager).

Install the **Python extension** from inside VS Code.

Do not start with Jupyter notebooks. Use plain `.py` files until Unit 9.

---

## 5. Your first program

1. In the terminal:

```
mkdir hello
cd hello
```

2. Create the file:

```
nano hello.py
```

Type:

```python
print("Hello, world")
```

Save with `Ctrl+O`, Enter, exit with `Ctrl+X`. (Or use VS Code.)

3. Run it:

```
python3 hello.py
```

You should see:

```
Hello, world
```

---

## 6. Common Linux problems

**`pip install` refuses with "externally-managed-environment".**
This is PEP 668 protection — modern distributions block installing packages into the system Python. It is a feature, not a bug. The fix is a virtual environment (Unit 6):

```
python3 -m venv .venv
source .venv/bin/activate
pip install <package>
```

**`python` is not found, but `python3` works.**
Expected on most distributions. Use `python3`. If you want `python` to mean Python 3, install the `python-is-python3` package (Debian/Ubuntu) or add an alias.

**`python3-venv` is missing.**
On Debian/Ubuntu, the venv module is a separate package: `sudo apt install python3-venv`.

**Permission errors.**
Never use `sudo pip install`. It installs into the system Python and can break your OS. Use a virtual environment.

**Multiple Python versions.**
Use `python3.12` explicitly, or manage versions with pyenv. Check which one you are running with `which python3` and `python3 --version`.

---

## 7. Line endings

Linux uses `\n` for line endings, same as macOS. This differs from Windows (`\r\n`). VS Code handles it automatically. If you use Git and share files with Windows users:

```
git config --global core.autocrlf input
```

---

## Next

Return to `units/unit-00-setup/` and complete the deliverable. Then begin Unit 1.
