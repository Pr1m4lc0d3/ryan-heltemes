﻿# Python: A Working Curriculum

A complete, self-contained course for learning Python as a discipline — not as a tour of syntax, and not as a path to one specific job. The goal is to think in a way that lets you build anything, and to know *why* what you built is correct.

This folder is designed to be archived and shipped as one unit. Everything a learner needs is inside it.

---

## What this is

A structured course of eleven units, from installing Python on any of the three major operating systems to building and testing a real program. Each unit ends in something that runs.

It is written for someone who wants to know it all — every platform, every core concept — and who is willing to do the work rather than watch it done.

---

## The three rules

These govern the whole course. Everything else follows from them.

1. **Every unit ends in a running program.** Not an exercise you "understand" — a file you execute and see output from. Understanding that is not demonstrated by execution is not yet understanding.

2. **You read as much as you write.** From Unit 3 onward, part of every week is spent reading a small, well-regarded open-source program and explaining it back. Reading code you did not write is the skill that separates people who can program from people who can follow tutorials.

3. **You show the error, not the intention.** When something breaks, you read the traceback. Learning to read a traceback is a core skill, not a detour.

---

## How the course is organised

```
python-curriculum/
├── README.md                  ← you are here
├── SYLLABUS.md                ← the full unit-by-unit overview
├── HOW-TO-USE.md              ← how to work through it, tutor or solo
├── setup/                     ← install Python on Windows, macOS, Linux
│   ├── windows/
│   ├── macos/
│   └── linux/
├── units/                     ← the eleven units
│   ├── unit-00-setup/
│   ├── unit-01-values/
│   ├── unit-02-control/
│   ├── unit-03-functions/
│   ├── unit-04-collections/
│   ├── unit-05-files-errors/
│   ├── unit-06-modules/
│   ├── unit-07-objects/
│   ├── unit-08-testing/
│   ├── unit-09-project/
│   └── unit-10-next/
├── reading/                   ← the standing reading assignment
└── projects/                  ← the Unit 9 project briefs in full
```

Each unit folder contains:
- `README.md` — the unit's concepts, explained
- `exercises.md` — what to build, with acceptance criteria
- `reading.md` — the program to read and what to look for

---

## The units at a glance

| Unit | Topic | Time |
|------|-------|------|
| 0 | Environment — install and run | ½ day |
| 1 | Values, names, and output | 1 week |
| 2 | Decisions and repetition | 2 weeks |
| 3 | Functions and structure | 2 weeks |
| 4 | Collections | 2 weeks |
| 5 | Files and errors | 2 weeks |
| 6 | Modules and the standard library | 2 weeks |
| 7 | Classes and objects | 2 weeks |
| 8 | Testing | 1 week |
| 9 | Real project | 4 weeks |
| 10 | Where to go next | ongoing |

Roughly four to five months at a steady pace. Faster if you have time; the units do not expire.

---

## The one idea underneath all of it

**Code is a moral act.** Every default you choose, every boundary you draw, every permission you grant encodes a value. A function that silently swallows an error has decided the caller does not need to know something went wrong. A name that lies about what the code does has planted a trap for whoever reads it next — often you, in six months.

Learning to program well is largely learning to notice these decisions and make them deliberately. This course treats that as a first-class skill, not a philosophy lecture. It shows up in the exercises: you will be asked not just whether your code runs, but what it does when it fails, and whether its names tell the truth.

---

## Start here

1. Read `HOW-TO-USE.md`.
2. Open `setup/` and follow the guide for your operating system.
3. Begin Unit 0.
