﻿# Syllabus

The full unit-by-unit overview. Each unit lists its concepts, its deliverable, and the structural idea it is really teaching.

---

## Unit 0 — Environment

**Time:** half a day
**Goal:** a working Python installation and the ability to run a file.

**Concepts:** installing Python 3.12+; the terminal (opening it, `cd`, listing files); the difference between a text editor and an IDE; the edit–run cycle.

**Deliverable:** a file `hello.py` that prints a message, executed from the terminal.

**Structural idea:** code that cannot run teaches nothing. The environment is not a preliminary — it is the ground the whole discipline stands on.

---

## Unit 1 — Values, names, and output

**Time:** 1 week

**Concepts:** integers, floats, strings, booleans, `None`; variables as names bound to values; `print()`, f-strings, `input()`; type conversion; comments and when they are noise.

**Deliverable:** an age calculator that reads a name and birth year and prints an age, handling text input.

**Structural idea:** a variable is a *name*, not a container. This distinction saves you later when you meet mutable objects.

---

## Unit 2 — Decisions and repetition

**Time:** 2 weeks

**Concepts:** `if`/`elif`/`else`; comparison and boolean operators; truthiness; `while` and its infinite-loop failure mode; `for` over ranges and sequences; `break`, `continue`; nested loops and their cost.

**Deliverable:** a number-guessing game; a Fibonacci printer; a prime checker.

**Structural idea:** off-by-one errors. Learn to predict loop bounds before you run, then verify by running.

---

## Unit 3 — Functions and structure

**Time:** 2 weeks

**Concepts:** defining functions; parameters and return values; `print` vs `return`; scope; default and keyword arguments; docstrings; naming as correctness.

**Deliverable:** the prime checker and Fibonacci program refactored into functions, plus a program that uses both.

**Structural idea:** a function should do one thing, and its name should say exactly what that thing is. If you cannot name it precisely, it is doing too much.

---

## Unit 4 — Collections

**Time:** 2 weeks

**Concepts:** lists and slicing; tuples and immutability; dictionaries; sets; comprehensions and when a loop is clearer; mutability and aliasing.

**Deliverable:** a word-frequency counter; a statistics program (mean, median, mode); a grade report from a dictionary.

**Structural idea:** mutable objects are shared by reference. `b = a` does not copy a list. Meet this deliberately now, not in a production bug later.

---

## Unit 5 — Files and errors

**Time:** 2 weeks

**Concepts:** reading and writing files with `with open(...)`; why `with` matters; CSV and JSON; `try`/`except`/`finally`; catching specific exceptions; safe failure.

**Deliverable:** a persistent to-do list that survives a corrupt file without losing data.

**Structural idea:** error handling is not decoration. A silent failure path is a defect. A program that cannot do what was asked should say so, not pretend.

---

## Unit 6 — Modules and the standard library

**Time:** 2 weeks

**Concepts:** `import` forms and why `import *` is banned; virtual environments; `pip` and `requirements.txt`; the standard library tour — `pathlib`, `datetime`, `random`, `collections`, `argparse`, `json`, `csv`.

**Deliverable:** the to-do list turned into a command-line tool with `add`, `list`, and `done` commands.

**Structural idea:** use the standard library before reaching for a third-party package. Every dependency is a liability you must maintain.

---

## Unit 7 — Classes and objects

**Time:** 2 weeks

**Concepts:** classes, instances, `__init__`, methods; `self`; attributes vs locals; `__repr__` and `__str__`; composition before inheritance; when *not* to write a class.

**Deliverable:** a `Deck` and `Card` pair that shuffles and deals, extended into a simple card game.

**Structural idea:** a class is a boundary. It exposes the operations that make sense and hides the internals. If callers reach in and mutate its attributes directly, the boundary has failed.

---

## Unit 8 — Testing

**Time:** 1 week

**Concepts:** `assert`; `pytest`; running tests and reading failures; testing the edges — empty input, zero, negatives, huge values; why a test that cannot fail is worse than no test.

**Deliverable:** test suites for the prime checker, the statistics functions, and the to-do tool.

**Structural idea:** "it worked on my machine" is not evidence. A passing test is evidence. This is where you stop hoping and start knowing.

---

## Unit 9 — Real project

**Time:** 4 weeks

**Concepts:** everything, applied. Structure, error handling, tests, documentation, a clean checkout that runs.

**Deliverable:** one program built end to end — an interpreter, a text-adventure engine, a `grep` clone, or similar. Chosen for difficulty, not usefulness.

**Structural idea:** architecture over accumulation. Long-term behaviour is governed by deliberate structure, not by feature count.

---

## Unit 10 — Where to go next

**Time:** ongoing

**Directions:** data (pandas, numpy, matplotlib), web (Flask/FastAPI, HTTP, databases), automation (scripting, APIs, `subprocess`), systems (concurrency, `asyncio`, performance, packaging).

**Structural idea:** go deep in one direction rather than wide in all of them. Breadth is what you have now; depth is what makes you useful.
