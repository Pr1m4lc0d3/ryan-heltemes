﻿# Project Brief — A Text-Adventure Engine

**Difficulty:** medium-high
**Time:** 4 weeks

---

## What you build

An engine that loads a world from a data file and lets a player explore it by typing commands.

The world is defined in JSON: rooms, exits between them, and items in each room.

```json
{
  "start": "hall",
  "rooms": {
    "hall": {
      "description": "A dusty entrance hall.",
      "exits": {"north": "library", "east": "kitchen"},
      "items": ["key"]
    },
    "library": {
      "description": "Shelves of rotting books.",
      "exits": {"south": "hall"},
      "items": []
    }
  }
}
```

The player types commands:

```
> look
A dusty entrance hall.
You see: key
Exits: north, east

> take key
You take the key.

> go north
You are in the library.
Shelves of rotting books.
Exits: south
```

---

## Why it is hard

- **State management.** The world changes as the player acts — items move, doors may lock. Keeping that state consistent is the core challenge.
- **Command parsing.** The player might type `go north`, `north`, `n`, or `GO NORTH`. The engine must handle all of them, and reject nonsense gracefully.
- **Data format design.** The JSON must be expressive enough to describe interesting worlds without becoming a programming language of its own.
- **Error handling.** `go west` when there is no west exit must produce a helpful message, not a crash.

---

## Structure

Suggested modules:

```
adventure/
├── world.py         # loads and validates the world data
├── player.py        # the player's state (current room, inventory)
├── commands.py      # parsing and dispatching commands
├── game.py          # the main loop
├── main.py          # entry point
└── tests/
    ├── test_world.py
    └── test_commands.py
```

---

## Requirements

- **The world loads from a file.** A missing or malformed file produces a clear error.
- **Commands:** `look`, `go <direction>`, `take <item>`, `drop <item>`, `inventory`, `quit`.
- **Aliases:** `n`/`s`/`e`/`w` for directions, `i` for inventory, `l` for look.
- **Unknown commands** produce a helpful message listing what is available.
- **Invalid moves** (no exit that way) produce a clear message.
- **Tests** for world loading and command parsing.
- **A README** explaining the world format and how to run it.

---

## Build order

1. **World loader first.** Read the JSON, validate it, hold it in a class. Test with a small world.
2. **Player state.** Current room, inventory.
3. **Command parser.** Turn input into a command and its argument. Test it hard — this is where most bugs live.
4. **The game loop.** Read input, dispatch, print result, repeat.
5. **Error handling pass.** Every bad input path gets a clear message.

---

## What "done" looks like

- A player can explore a multi-room world, take and drop items, and quit.
- Every bad input produces a helpful message.
- The tests pass.
- The README explains the world format well enough that someone could write a new world.

---

## Stretch goals

- Locked doors that need a key.
- Rooms that change when an item is taken.
- Saving and loading the player's progress.
- A simple win condition.
