﻿# Setting up Python on Windows

Everything here is done once. When you finish, you will be able to open a terminal, type `python`, and run a program.

---

## 1. Install Python

**Do not** install Python from the Microsoft Store. It works, but it installs into a sandboxed location that causes confusing problems later with virtual environments and PATH. Install from the official source.

1. Go to **https://www.python.org/downloads/windows/** and download the latest **Windows installer (64-bit)** for Python 3.12 or later.
2. Run the installer.
3. **On the first screen, tick the box that says "Add python.exe to PATH".** This is the single most important step. If you miss it, the `python` command will not work from the terminal and you will have to reinstall or fix PATH by hand.
4. Click **Install Now**.
5. When it finishes, click **Disable path length limit** if offered. This removes the 260-character path limit, which some projects need.

### Verify

Open a **new** terminal (PowerShell or Command Prompt — see below) and type:

```
python --version
```

You should see something like `Python 3.12.4`. If you see an error, the PATH step was missed — reinstall and tick the box.

Also check pip, the package installer:

```
python -m pip --version
```

---

## 2. Choose a terminal

Windows has two terminals that matter:

- **PowerShell** — the modern default. Recommended.
- **Command Prompt (`cmd`)** — older, still present.

Open PowerShell by pressing `Win`, typing `powershell`, and pressing Enter. Or press `Win+X` and choose **Terminal**.

The commands you need:

| Task | PowerShell | Command Prompt |
|------|-----------|----------------|
| List files | `ls` or `dir` | `dir` |
| Change directory | `cd folder` | `cd folder` |
| Go up one level | `cd ..` | `cd ..` |
| Go to your home folder | `cd ~` | `cd %USERPROFILE%` |
| Show current directory | `pwd` | `cd` |
| Make a folder | `mkdir name` | `mkdir name` |

Use `cd` to move to where you want to keep your work. For example:

```
mkdir code
cd code
```

---

## 3. Choose an editor

Install **Visual Studio Code**: https://code.visualstudio.com/

During install, tick **"Add to PATH"** and **"Open with Code"** for files and folders.

Then install the **Python extension** from inside VS Code (Extensions panel, search "Python", install the Microsoft one). This gives you syntax highlighting, running, and debugging.

Do not start with Jupyter notebooks. They hide the file-and-run cycle you need to internalise first. Use plain `.py` files until Unit 9.

---

## 4. Your first program

1. In your terminal, make a folder and enter it:

```
mkdir hello
cd hello
```

2. Create the file with Notepad (or VS Code):

```
notepad hello.py
```

3. Type exactly this:

```python
print("Hello, world")
```

4. Save and close.

5. Run it:

```
python hello.py
```

You should see:

```
Hello, world
```

That is the whole edit–run cycle. Everything from here is built on it.

---

## 5. Common Windows problems

**`python` opens the Microsoft Store instead of running.**
This is the Store's stub intercepting the command. Either turn off the App Execution Aliases for Python (Settings → Apps → Advanced app settings → App execution aliases → turn off `python.exe` and `python3.exe`), or reinstall Python from python.org with PATH enabled.

**`python` is not recognised as a command.**
PATH was not set during install. Reinstall and tick "Add python.exe to PATH", or add the install folder manually to your PATH environment variable.

**`python` runs Python 2.**
Unlikely on modern Windows, but if a very old install is present, use `py -3` to force Python 3, or remove the old install.

**Permission errors when installing packages.**
Do not use `pip install` with administrator rights. Use a virtual environment (Unit 6) instead. Installing into the system Python is what causes this.

---

## 6. Line endings (why files sometimes look wrong)

Windows uses `\r\n` for line endings; Linux and macOS use `\n`. This matters when sharing files or using Git. VS Code handles it automatically. If you later use Git, set it once:

```
git config --global core.autocrlf true
```

Not needed for the early units, but worth knowing before it confuses you.

---

## Next

Return to `units/unit-00-setup/` and complete the deliverable. Then begin Unit 1.
