﻿# Setting up Python on macOS

Everything here is done once. When you finish, you will be able to open a terminal, type `python3`, and run a program.

---

## 1. Understand what macOS already has

macOS ships with a version of Python, but you should **not** use it. It is tied to the operating system, it is often outdated, and Apple advises against modifying it. Leave the system Python alone and install your own.

---

## 2. Install Python

You have two good options. Pick one.

### Option A — Official installer (simplest)

1. Go to **https://www.python.org/downloads/macos/** and download the latest macOS installer for Python 3.12 or later.
2. Open the `.pkg` and follow the steps.
3. This installs Python and adds it to your PATH.

### Option B — Homebrew (recommended if you will use the terminal a lot)

Homebrew is a package manager for macOS. If you do not have it:

```
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
```

Then install Python:

```
brew install python
```

Homebrew keeps Python up to date and manages dependencies cleanly.

### Verify

Open **Terminal** (press `Cmd+Space`, type `terminal`, Enter) and run:

```
python3 --version
```

You should see `Python 3.12.x` or later. Note the **`3`** — on macOS, `python` alone may refer to the old system version or nothing at all. Always use `python3` unless you have deliberately set up an alias.

Check pip:

```
python3 -m pip --version
```

---

## 3. The terminal

macOS uses **zsh** by default (older versions used bash). The commands:

| Task | Command |
|------|---------|
| List files | `ls` |
| Change directory | `cd folder` |
| Go up one level | `cd ..` |
| Go home | `cd ~` |
| Show current directory | `pwd` |
| Make a folder | `mkdir name` |

Move to where you want to keep your work:

```
mkdir code
cd code
```

---

## 4. Choose an editor

Install **Visual Studio Code**: https://code.visualstudio.com/

Install the **Python extension** from inside VS Code (Extensions panel, search "Python", install the Microsoft one).

Do not start with Jupyter notebooks. Use plain `.py` files until Unit 9.

---

## 5. Your first program

1. In Terminal:

```
mkdir hello
cd hello
```

2. Create the file:

```
nano hello.py
```

Type:

```python
print("Hello, world")
```

Save with `Ctrl+O`, Enter, then exit with `Ctrl+X`. (Or create the file in VS Code instead.)

3. Run it:

```
python3 hello.py
```

You should see:

```
Hello, world
```

---

## 6. Common macOS problems

**`python` is not found, but `python3` works.**
Expected. Use `python3`. If you want `python` to mean Python 3, add an alias to `~/.zshrc`:

```
alias python=python3
```

Then run `source ~/.zshrc`.

**`pip` is not found.**
Use `python3 -m pip` instead of `pip`. This always works and avoids PATH issues.

**Permission errors on `pip install`.**
Do not use `sudo pip`. Use a virtual environment (Unit 6). Installing into the system Python with `sudo` can break your system.

**The system Python interferes.**
If you see a warning about the system Python, you are running the wrong interpreter. Use `python3` and confirm with `which python3` — it should point to your Homebrew or python.org install, not `/usr/bin/python3`.

**Apple Silicon (M1/M2/M3) notes.**
Modern Python installers and Homebrew both support Apple Silicon natively. If a package fails to install, it may lack a prebuilt wheel for ARM — check the package's documentation. This is rare now.

---

## 7. Line endings

macOS uses `\n` for line endings, same as Linux. This differs from Windows (`\r\n`). VS Code handles it automatically. If you use Git and share files with Windows users:

```
git config --global core.autocrlf input
```

---

## Next

Return to `units/unit-00-setup/` and complete the deliverable. Then begin Unit 1.
