# Wasteland Faction Kit

A DM kit for **MADDMAX** — Mad Max by way of D&D. No magic. Chrome, dust, fuel, blood.

Build a runner from 24 cards, then play. Either copy the prompt into any AI you already
use, or paste a free key and play without leaving the page.

**One file. No install, no build step, no dependencies.** Double-click `index.html`
and it runs.

---

## How to play

1. **BUILD** — tap a slot, pick a card. Six slots: character, ride, relic, mod, salvage, mission.
   Leave any of them empty and the AI improvises around it.
2. **PLAY → COPY PROMPT** — one button. Paste it into Meta AI, ChatGPT, Claude, anything
   that talks back.
3. Or **PLAY → PLAY HERE** — paste a free OpenRouter key and the game runs in the page,
   with your choices as buttons and your resources tracked on screen.

**RULES** and **DECK** are reachable from anywhere, any time, from the top bar.

---

## Playing in the page

You need a key from [openrouter.ai/keys](https://openrouter.ai/keys). It's free and takes
about two minutes. The default model costs nothing — no card required, roughly 50 turns a day.

The key is stored in your browser and sent to OpenRouter and nowhere else. There is no
server here. There is nothing to sign up for.

---

## Changing the game

Open `index.html` in any text editor. Near the top of the `<script>` block you'll find:

- `FACTIONS` — the six factions and their colours
- `RARITY` — what common / rare / legendary actually cost you
- `CARDS` — all 24 cards

A card is one line. Copy any line, change the words, and reload the page. That's the
whole process — nothing to compile, nothing to install.

```js
{ id:25, cat:"RELIC", faction:"nomads", rarity:"rare", title:"YOUR CARD",
  stat:"WHAT IT DOES | IN NUMBERS", rule:"How it works at the table.",
  flavor:"One good line." },
```

---

## Card art

The cards look for `art/01.webp` … `art/24.webp`, numbered to match each card's `id`.
Any file that isn't there falls back to a drawn sigil, so a half-finished art set still
looks deliberate.

`art/PROMPTS.md` holds a written prompt for all 24, plus the shared house style that keeps
them looking like one deck. Paste them into any image generator, save the results into
`art/`, and the page picks them up — no code change.

---

## Credits

Cards, world and voice by the original author. Every card title, stat, rule and flavour
line is his, word for word.

This rebuild restructured the interface, collected the rules into one place, wired the
factions to the cards, gave rarity a real cost, and added in-page play.
