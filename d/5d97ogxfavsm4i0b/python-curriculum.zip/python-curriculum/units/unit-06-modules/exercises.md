﻿# Unit 6 — Exercises

---

## Exercise 6.1 — Split into modules

Take your statistics functions from Unit 4 and put them in a file `stats.py`. Write a separate `main.py` that imports and uses them.

**Requirements:**
- `stats.py` must not run anything on import — guard any test code with `if __name__ == "__main__":`.
- `main.py` imports only what it uses.

**Done when:** running `main.py` works, and importing `stats.py` from another file runs nothing.

---

## Exercise 6.2 — Virtual environment

Create a virtual environment for a new folder. Activate it. Install a package (`requests` is a good choice). Confirm it is installed in the environment, not globally.

**Requirements:**
- Deactivate and run `python -c "import requests"` — it should fail, proving the package was in the environment, not the system.
- Reactivate and confirm it works.
- Run `pip freeze > requirements.txt` and look at the file.

**Done when:** you can explain, in one sentence, why installing globally is a problem.

---

## Exercise 6.3 — Standard library exploration

Without writing a program, use the Python interpreter (`python` with no file) to explore:

1. `import collections; help(collections.Counter)` — what does `most_common` do?
2. `from pathlib import Path; help(Path)` — list three methods you would use.
3. `import datetime; datetime.date.today()` — what does it return?

**Done when:** you can name three standard-library modules and one thing each does, without looking them up.

---

## Exercise 6.4 — Command-line to-do tool

The main deliverable for this unit. Turn your Unit 5 to-do list into a command-line tool.

**Requirements:**
- Use `argparse` with subcommands: `add`, `list`, `done`.
- `add "buy milk"` adds an item.
- `list` prints all items with an index and done/not-done status.
- `done 2` marks item 2 as done.
- Use `pathlib` for the file path.
- Store data in a JSON file next to the script.
- Invalid input (a non-existent index, a missing argument) must produce a clear error, not a traceback.

**Done when:** all three commands work, the data persists, and bad input is handled.

**Example use:**

```
python todo.py add "write the curriculum"
python todo.py add "test it"
python todo.py list
python todo.py done 1
python todo.py list
```

---

## Exercise 6.5 — Name the module honestly

A file called `utils.py` has grown to contain date formatting, file reading, string cleaning, and a database connection. Explain why the name `utils.py` is a defect, and propose how to split it.

**Done when:** you have proposed at least three files, each with a name that says what it contains.
