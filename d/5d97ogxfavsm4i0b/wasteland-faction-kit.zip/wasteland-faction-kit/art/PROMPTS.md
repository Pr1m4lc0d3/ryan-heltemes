# Card art — 24 generation prompts

Written with the `ekphrasis` method: specificity plus constraint, one committed light
source, an explicit medium, and a negative line that names the failure modes.

## How to use these

Paste `HOUSE STYLE` + one `SUBJECT` line into any image generator (Gemini / Nano Banana,
Flux, Ideogram, Midjourney, DALL·E, or the Binary Gold GFX specialist). Generate a few,
pick the best, then steer in words — a generic first result is normal, not failure.

Save results as `art/01.webp` … `art/24.webp`, numbered to match the card `id`.
**The page picks them up automatically.** No code change. Any file that is missing
falls back to a drawn sigil, so a half-finished set still looks deliberate.

Target size **640×360**, downscaled to WebP q72. They display at roughly 200×120,
which is why every prompt below asks for silhouette-strength shapes and forbids fine detail.

---

## HOUSE STYLE — prepend to every subject

> Flat two-colour screen-print poster illustration. **Rust-orange and black only**,
> coarse halftone dot texture, ink broken and patchy like a worn print. Bold
> high-contrast silhouette shapes that read clearly when printed small. Hard low sun
> from the left, long shadows raking right. Subject placed off-centre to the left with
> open space on the right. Full bleed, edge to edge.
>
> **Negative:** absolutely no text, no lettering, no numerals, no signage, no labels,
> no watermark. No border, no frame, no paper edge. No photorealism, no 3d render,
> no gloss, no lens flare.

⚠ **Two wordings that look right and are not.** Both were tried and both failed:

- **"a plate from a field manual"** makes the generator draw *a photograph of a printed
  page* — paper edges, margins, the book itself. Describe the illustration, never the
  object it is printed on. Hence "full bleed, edge to edge" and the explicit
  no-border line.
- **"ink on paper stock"** pulls toward photographed texture and semi-photorealism.
  "Flat two-colour screen-print poster" holds the graphic look far better.

### The one exception — Mutant cards

Cards **03, 11, 19** belong to the Mutants, the Sixth Faction. For these three only,
swap the ink: **toxic green ink instead of rust-orange, on the same dark paper.**
Everything else identical. This is the only colour break in the deck, and it is the
reason it reads as a break.

---

## SUBJECTS

### Salvage

**01 · SCRAP PILE ALPHA**
> A heap of stripped car bodies pushed into a mound, doors and bonnets tangled. One
> car door stands upright in the pile like a headstone. Loose sand banked against the base.

**02 · MUNITIONS CACHE**
> A wooden ammunition crate with its lid levered half off, heavy shells standing upright
> in packing straw. The crate sits at a tilt where the ground has given way beneath one corner.

**03 · LOST CONVOY Z-9** — *green ink*
> A line of heavy trucks buried to their roofs in a dune, only the cab tops and a bent
> exhaust stack breaking the surface, receding away into haze. Unbroken sand in the foreground.

### Garage

**04 · WELD & PATCH**
> A crude steel patch plate welded over a torn truck fender, the weld bead thick and lumpy,
> the plate a different metal from the panel around it. Seen close, at a steep angle.

**05 · ENGINE OVERHAUL**
> A heavy engine block hanging from chains on an A-frame hoist, swinging slightly clear of
> an open engine bay. Tools scattered on a tarpaulin below.

**06 · BLACK MARKET TUNE**
> A machined engine part wrapped loosely in oilcloth, resting on a tailgate. The cloth is
> folded back just enough to show the metal. Nobody in frame.

### Relic

**07 · RUST MOTHER'S LOCKET**
> A heavy oval locket hanging open on a broken chain, exposing a nest of tiny brass gears
> where a portrait should be. Hangs against a rusted panel.

**08 · GUSSAR WAR HORN**
> A long curved brass war horn bolted to the roof of a truck cab, mouth flared and dented,
> lashed down with wire. Seen from below against open sky.

**09 · GEIGER SIGIL**
> A flat cast-metal pendant, roughly triangular, with a small round gauge set into its face
> and a bent needle behind cracked glass. Hanging from a bootlace.

### Mission

**10 · SECURE THE WATER RIG**
> A squat drilling derrick standing over a capped wellhead, ringed by stacked sandbags and
> a coil of hose. Flat open ground all around it.

**11 · HUNT LEVIATHAN** — *green ink*
> An enormous ridged spine breaking the surface of a sand sea like a whale's back, dwarfing
> a tiny vehicle in the far distance. Sand pouring off the ridge.

**12 · GHOST CONVOY**
> Faint truck silhouettes almost lost in blown dust, only wheels and roof lines resolving,
> the rest dissolving into the haze. Mostly empty frame.

### Vehicle

**13 · IRON MASTIFF**
> A heavy armoured hauler with a blunt ram plate across its nose, slab armour over the
> wheels, riding low under cargo. Side-on three-quarter view, parked.

**14 · RUST VULTURE**
> A stripped lightweight buggy — exposed roll cage, no bodywork, bucket seat, oversized
> rear tyres. Side-on three-quarter view.

**15 · SCARAB CRAWLER**
> A low wide six-wheeled crawler with a heavy winch drum mounted on its nose and a cable
> paying out onto the ground. Hunkered close to the dirt.

**16 · NEON COYOTE**
> A needle-nosed speedster, long and low with a tapered tail and an oversized exhaust
> stack, built for nothing but speed. Side-on, wheels turned.

**17 · GARAMANDER**
> An enormous slab-sided tanker truck, tall and square, plated over every window but the
> windscreen slit. Seen from a low angle so it towers.

**18 · DUST MOTHER**
> A converted crew bus with a roof rack piled high with bedrolls and jerry cans, ladders
> lashed to the back. Side-on, doors open.

### Character

*Faces are wrapped, turned or hidden in every one of these — deliberately. A face rendered
at 200 pixels wide goes uncanny, and the wrap is truer to the setting anyway.*

**19 · ASH RUNNER** — *green ink*
> A lean figure caught mid-stride at a run, face entirely wrapped in cloth, goggles over
> the wrap, a short cloak streaming behind. Seen from the side, both feet off the ground.

**20 · IRON MAW**
> A bulky heavyset figure standing square-on, a welded steel jaw guard covering the lower
> face, shoulders plated with scrap. Arms loose at the sides.

**21 · DUST MATRIARCH**
> An older woman in a heavy shawl, seen three-quarters from behind, one hand resting on a
> dented canteen at her hip. Her face is turned away toward the horizon.

**22 · CINDER JACK**
> A figure in a scorched rig harness with short flame vents over each shoulder, seen from
> behind against the low sun, heat shimmer rising. Face not visible.

**23 · VAULT HOUND**
> A figure crouched low on knuckles in a tracker's posture, heavy goggles and a breathing
> filter covering the face, head turned sharply to one side, listening.

**24 · SCRAP SAINT**
> A thin figure in a tool bandolier heavy with spanners, head bowed over work, a halo of
> bent wire and scavenged glass fixed behind the head on a frame. Seen in profile.
