﻿# Unit 7 — Reading assignment

**Read:** the `pathlib` module from the standard library.

Find it:

```bash
python -c "import pathlib; print(pathlib.__file__)"
```

This is a large module. Read the `Path` class — its `__init__`, a few methods, and its operators.

---

## What to look for

1. **How a concept is modelled.** `Path` is not a bundle of functions; it is an object that *is* a file path. What behaviour does it give that path?

2. **Operators.** Find `__truediv__`. What does it do, and why does it make `Path("a") / "b"` work?

3. **`__repr__` and `__str__`.** Find them. What does each return, and why are they different?

4. **Properties.** Find `parent`, `name`, `suffix`. These are not methods — they are properties. Why does that distinction matter?

5. **Immutability.** Does `Path` mutate itself, or return new objects? Find a method that returns a new `Path` rather than changing the existing one.

---

## Questions to answer

1. What does `Path` model, in one sentence?
2. Find `__truediv__`. What does it let you do that a string cannot?
3. Find three properties and three methods. What is the difference, and why is each one chosen?
4. Does `Path` mutate or return new objects? Give an example.
5. What did you learn about class design that you will use?

---

## Why this module

`pathlib` is a masterclass in modelling a concept as a class. It shows how a well-designed object gives you behaviour (joining, resolving, checking existence) rather than just holding data (a string). It also demonstrates the difference between properties and methods, and why immutability is often the safer choice. Read it with your own `Deck`/`Card` class in mind.
