﻿# Unit 0 — Environment

**Time:** half a day
**Prerequisite:** none

---

## What this unit is for

Code that cannot run teaches nothing. Before any programming, you need a working Python installation and the ability to create a file and execute it. This unit is short but it is not optional — every later unit assumes it.

If you have not yet installed Python, do that first. Follow the guide for your operating system:

- `setup/windows/README.md`
- `setup/macos/README.md`
- `setup/linux/README.md`

---

## The edit–run cycle

This is the loop you will repeat thousands of times:

1. **Edit** a file — write or change code in a text editor.
2. **Save** it.
3. **Run** it — execute it from the terminal with `python file.py`.
4. **Read the output** — what it printed, or what error it raised.
5. **Go back to step 1.**

Everything else in programming is built on this loop. Get comfortable in it.

---

## The terminal

You will live in the terminal. The minimum you need:

| Task | Windows (PowerShell) | macOS / Linux |
|------|---------------------|---------------|
| List files | `ls` or `dir` | `ls` |
| Change directory | `cd folder` | `cd folder` |
| Go up one level | `cd ..` | `cd ..` |
| Go home | `cd ~` | `cd ~` |
| Current directory | `pwd` | `pwd` |
| Make a folder | `mkdir name` | `mkdir name` |

The terminal is not an obstacle between you and programming. It *is* the environment programming happens in.

---

## Editor vs IDE

- A **text editor** edits text. Notepad, nano, VS Code in its basic form.
- An **IDE** (Integrated Development Environment) adds running, debugging, autocomplete, and project management.

VS Code sits in between and is a good choice. But resist installing heavy tooling now. The point of Unit 0 is to feel the bare edit–run cycle, not to have it hidden behind a button.

**Do not use Jupyter notebooks yet.** They hide the file-and-run cycle behind cells. You need to internalise that a program is a file you execute. Notebooks come later, if at all.

---

## The traceback

When your program fails, Python prints a **traceback** — a report of what went wrong and where. Learning to read it is a core skill.

Example:

```
Traceback (most recent call last):
  File "hello.py", line 2, in <module>
    print(greeting)
NameError: name 'greeting' is not defined
```

Read it **bottom-up**:

1. **Last line:** the error type and message — `NameError: name 'greeting' is not defined`.
2. **Line above:** the exact line of code that caused it — `print(greeting)`.
3. **Above that:** the file and line number — `hello.py, line 2`.

The message tells you *what*; the traceback tells you *where*. Together they usually tell you *why*.

---

## Deliverable

Create a file `hello.py` that prints a greeting, and run it from the terminal. Then deliberately introduce an error (misspell a variable, or remove the quotes from a string) and read the traceback it produces. Fix it.

You are done with Unit 0 when you can:

- Create a `.py` file and run it.
- Navigate the terminal with `cd`, `ls`, and `mkdir`.
- Read a traceback and say which line and which error it names.

Proceed to Unit 1.
