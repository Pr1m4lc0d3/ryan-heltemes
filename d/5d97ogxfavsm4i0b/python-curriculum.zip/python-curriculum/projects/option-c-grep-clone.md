﻿# Project Brief — A `grep` Clone

**Difficulty:** medium
**Time:** 4 weeks

---

## What you build

A program that searches files for a pattern and prints matching lines. It is a simplified version of the Unix `grep` tool.

```
python mygrep.py "hello" file.txt
python mygrep.py -i "HELLO" file.txt        # case-insensitive
python mygrep.py -n "error" log.txt         # show line numbers
python mygrep.py -r "TODO" src/             # recurse into a directory
```

---

## Why it is hard

- **Regular expressions.** The pattern is not just a literal string — it can be a regex. You must use the `re` module correctly and handle invalid patterns.
- **Walking a directory tree.** Recursion, and deciding what to do with files you cannot read.
- **Binary files.** A file might not be text. Reading it as text raises an error; you must detect and skip it.
- **Permissions.** A file might not be readable. That must not crash the program.
- **Matching real behaviour.** `grep` has subtle behaviours — how it handles multiple files, how it formats output — and matching them teaches you to read a specification carefully.

---

## Structure

Suggested modules:

```
mygrep/
├── matcher.py       # compiles the pattern, tests lines against it
├── searcher.py      # searches one file, yields matches
├── walker.py        # walks a directory, yields files
├── formatter.py     # formats output (line numbers, filenames)
├── cli.py           # argument parsing
├── main.py          # entry point
└── tests/
    ├── test_matcher.py
    └── test_searcher.py
```

---

## Requirements

- **A pattern argument and one or more file arguments.**
- **`-i`** for case-insensitive matching.
- **`-n`** to prefix each match with its line number.
- **`-r`** to recurse into directories.
- **Regular expressions** via the `re` module. An invalid pattern produces a clear error.
- **Binary files are skipped** without crashing.
- **Unreadable files** produce a warning on stderr, and the search continues.
- **Exit code 0** if any match was found, **1** if none, **2** on error. (This is what real `grep` does.)
- **Tests** for the matcher and the searcher.
- **A README** documenting the options.

---

## Build order

1. **Matcher first.** Given a pattern and a line, does it match? Test it thoroughly.
2. **Searcher.** Given a file and a pattern, yield matching lines. Handle unreadable and binary files.
3. **CLI.** Parse the arguments with `argparse`.
4. **Wire together.** Search each file the user named, format the output.
5. **Recursion.** Add `-r` last — it depends on everything else working.
6. **Exit codes.** Get them right; they matter for scripting.

---

## What "done" looks like

- All four example commands work.
- A binary file in the search path is skipped, not crashed on.
- An invalid regex produces a clear message and exit code 2.
- The tests pass.
- The README documents every option.

---

## Stretch goals

- `-v` to invert the match (print non-matching lines).
- `-c` to print only a count of matches.
- `-l` to print only the names of files that matched.
- Colour output for the matched portion.
