﻿# Unit 6 — Modules and the standard library

**Time:** 2 weeks
**Prerequisite:** Unit 5

---

## Why modules

No one writes everything from scratch. Python ships with a large **standard library** — code that is already written, tested, and maintained, covering dates, files, maths, text, networking, and more. Using it is not cheating; it is the correct engineering choice. Every line you do not write is a line you do not have to debug.

---

## Importing

```python
import math
math.sqrt(16)            # 4.0

from math import sqrt
sqrt(16)                 # 4.0

from pathlib import Path
```

**Never use `import *`:**

```python
from math import *       # BAD
```

It dumps every name from the module into your namespace. You can no longer tell where a name came from, and two modules with the same name silently overwrite each other. It also makes the code impossible to read: a reader cannot tell whether `sqrt` is yours or imported.

Import what you need, explicitly.

---

## Your own modules

Any `.py` file is a module. If you have `helpers.py`:

```python
# helpers.py
def double(n):
    return n * 2
```

You can import it from another file in the same folder:

```python
# main.py
import helpers
print(helpers.double(5))
```

This is how you split a growing program into files. **A file should have one clear purpose, and its name should say what it is.** `helpers.py` is a bad name — it says nothing. `text_utils.py` or `math_utils.py` says something.

---

## The `if __name__ == "__main__":` guard

When you import a module, Python runs its top-level code. That is usually not what you want — importing a module should not execute its main program. Guard the entry point:

```python
# tools.py
def main():
    print("running")

if __name__ == "__main__":
    main()
```

`__name__` is `"__main__"` only when the file is run directly. When imported, it is the module's name, and the guard is skipped. This lets a file be both a runnable program and an importable module.

---

## Virtual environments

A **virtual environment** is an isolated Python installation for one project. It matters because different projects need different versions of the same package, and installing globally causes conflicts.

```bash
# create
python -m venv .venv

# activate — Windows (PowerShell)
.venv\Scripts\Activate.ps1

# activate — Windows (cmd)
.venv\Scripts\activate.bat

# activate — macOS / Linux
source .venv/bin/activate

# deactivate
deactivate
```

When active, `pip install` installs into the environment, not the system. Your prompt usually shows `(.venv)` to confirm.

**Every project gets its own virtual environment.** No exceptions. Installing packages into the system Python is how people break their operating system's tooling.

---

## pip and requirements.txt

`pip` installs packages:

```bash
pip install requests
```

Record what a project needs:

```bash
pip freeze > requirements.txt
```

Reproduce the environment elsewhere:

```bash
pip install -r requirements.txt
```

---

## The standard library tour

These are the modules you will reach for most. Learn that they exist; look up the details as needed.

| Module | For |
|--------|-----|
| `pathlib` | File paths, cross-platform |
| `datetime` | Dates and times |
| `random` | Random numbers and choices |
| `collections` | `Counter`, `defaultdict`, `namedtuple` |
| `argparse` | Command-line arguments |
| `json` | JSON reading and writing |
| `csv` | CSV reading and writing |
| `os` / `sys` | Operating system interface, interpreter |
| `re` | Regular expressions |
| `math` | Mathematical functions |
| `statistics` | mean, median, mode |
| `itertools` | Efficient iteration tools |
| `subprocess` | Running other programs |

A few worth seeing now:

```python
from collections import Counter
Counter("hello")            # Counter({'l': 2, 'h': 1, 'e': 1, 'o': 1})

from datetime import date
date.today()

import random
random.choice(["a", "b", "c"])
```

---

## Command-line arguments

`argparse` turns a script into a real command-line tool:

```python
import argparse

parser = argparse.ArgumentParser(description="Say hello.")
parser.add_argument("name", help="who to greet")
parser.add_argument("--loud", action="store_true", help="shout it")

args = parser.parse_args()

message = f"Hello, {args.name}"
print(message.upper() if args.loud else message)
```

Run as `python greet.py Ada --loud`. This is what makes a script usable by others — including your future self.

---

## Structural idea for this unit

**Use the standard library before reaching for a third-party package.** Every dependency is a liability: it can break, be abandoned, or conflict with another. The standard library is maintained by the same people who maintain Python, and it ships with the language. Reach for it first.

---

## Deliverable

Turn the to-do list from Unit 5 into a command-line tool with `add`, `list`, and `done` commands, using `argparse` and `pathlib`. See `exercises.md`.
