﻿# How to use this curriculum

Two ways to work through this: with a tutor, or alone. Both are legitimate. The difference is who reads your code and tells you what is wrong with it.

---

## Working with a tutor

For each unit:

1. **Read the unit's `README.md`.** Then read the `reading.md` program and explain it back in your own words before writing anything. If you cannot explain it, you have not read it.
2. **Write the exercise** in `exercises.md`. Show the code and its output.
3. **The tutor reviews it.** Expect defects to be named by severity — cosmetic, unclear, misleading, structural — and expect to fix them yourself. A tutor who rewrites your code for you has taken the learning away from you.
4. **Fix it and move on.**

The tutor's job is to name the defect and tell you what to try. The typing is yours.

---

## Working alone

You can do this without a tutor, but you must replace the missing feedback loop with something disciplined.

1. **Write the exercise. Run it.**
2. **Then do the review yourself, honestly.** Read your own code as if someone else wrote it. Ask: does every name tell the truth? Does every function do one thing? What happens on empty input, on zero, on a negative number, on a million?
3. **Break it on purpose.** Feed it bad input. Delete a file it needs. See whether it fails loudly or silently. A silent failure is a defect you have to fix.
4. **Compare against the reference where one is given.** Do not copy it — compare structure. Where did you differ, and which version would you rather maintain?

If you can find a study partner or an online community to review your code, do. Reading someone else's critique of your work is one of the fastest ways to improve.

---

## The pace

The times given are for someone studying part-time. Do not rush. A unit is finished when the exercise runs and you can explain *why* it is written the way it is — not when you have read the page.

If a unit takes twice as long, that is normal. If you skip the exercise, you have not done the unit.

---

## The standing reading assignment

From Unit 3 onward, every week includes reading a small open-source program. This is not optional and it is not busywork. It is the single highest-leverage habit available to a learner: you can only learn from code you are allowed to read, and reading good code teaches structure in a way that writing your own never quite does.

The `reading/` folder holds the assignment list and the questions to answer for each.

---

## What "done" means

A unit is done when:

- The exercise runs and produces correct output.
- You can explain the code's structure to someone else.
- You have deliberately broken it and watched it fail in a way you understand.
- Its names tell the truth about what it does.

Anything less is not done. There is no partial credit for reading.

---

## A note on the tools

You do not need an expensive setup. A plain text editor, a terminal, and Python. Resist the urge to install a large framework or an AI autocomplete before you can write a loop from memory — those tools are useful later, but early on they do the thinking you are trying to learn to do.
