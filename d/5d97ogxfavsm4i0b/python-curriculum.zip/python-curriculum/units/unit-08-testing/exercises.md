﻿# Unit 8 — Exercises

---

## Exercise 8.1 — First tests

Write three `assert` statements that test your `add` function (or `is_prime`). Run the file. Then change one assertion to something false and run it again — read the `AssertionError`.

**Done when:** you have seen a test pass and a test fail, and can read both.

---

## Exercise 8.2 — pytest setup

Create a virtual environment, install `pytest`, and write `test_stats.py` testing your statistics functions from Unit 4.

**Requirements:**
- One test per function, minimum.
- At least one edge-case test per function (empty list, single value).
- Run with `pytest` and confirm all pass.

**Done when:** `pytest` reports all tests passing.

---

## Exercise 8.3 — Make a test fail on purpose

Take one test that passes. Now deliberately break the function it tests — return the wrong value. Run the tests again.

**Requirements:**
- Confirm the test goes red.
- Read the failure output and identify the line and the actual vs expected value.
- Restore the function.

**Done when:** you have proven the test can fail. A test that cannot fail is not a test.

---

## Exercise 8.4 — Find the bug from the test

Here is a function and its test. The test fails. Find the bug by reading, then fix the function.

```python
def median(numbers):
    numbers.sort()
    n = len(numbers)
    return numbers[n // 2]

def test_median_even():
    assert median([1, 2, 3, 4]) == 2.5
```

**Requirements:**
- Explain what the function returns for an even-length list and why it is wrong.
- Fix it so the test passes.
- Add a test for an empty list.

**Done when:** all tests pass and the empty-list case is handled deliberately.

---

## Exercise 8.5 — Test the to-do tool

Write tests for your command-line to-do tool from Unit 6.

**Requirements:**
- Test adding an item.
- Test marking an item done.
- Test listing returns what was added.
- Test that a bad index raises or reports a clear error.
- Use a temporary file for the tests, so the real data is not touched.

**Done when:** the tests pass, and running them does not modify your actual `todos.json`.

---

## Exercise 8.6 — Write a test that cannot fail

Write a test that always passes, then explain in a comment why it is worthless. Then rewrite it as a real test.

**Done when:** you can articulate the difference between a test that passes and a test that *means* something.
