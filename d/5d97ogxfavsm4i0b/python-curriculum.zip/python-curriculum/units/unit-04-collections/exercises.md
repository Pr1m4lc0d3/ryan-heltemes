﻿# Unit 4 — Exercises

---

## Exercise 4.1 — The aliasing trap

Run this and explain the output. Then fix it so `a` is unchanged.

```python
a = [1, 2, 3]
b = a
b.append(4)
print(a)
print(b)
```

**Done when:** you can explain, in one sentence, why `a` changed.

---

## Exercise 4.2 — Statistics

Write three functions:

- `mean(numbers)` — the average
- `median(numbers)` — the middle value (sort first; for an even count, average the two middle values)
- `mode(numbers)` — the most frequent value

**Requirements:**
- Each returns a number, does not print.
- Handle an empty list by returning `None` (decide and document what makes sense).
- No external libraries — implement them yourself.

**Done when:** `[1, 2, 2, 3, 4]` gives mean `2.4`, median `2`, mode `2`.

---

## Exercise 4.3 — Word frequency

Write a function that takes a string and returns a dictionary of word counts.

**Requirements:**
- Split on whitespace.
- Lowercase everything so `The` and `the` count together.
- Strip basic punctuation (`.`, `,`, `!`, `?`).

Then write a program that prints the top ten words by frequency.

**Done when:** a paragraph of text produces a sensible ranked list.

---

## Exercise 4.4 — Grade report

Store student names and grades in a dictionary. Print a report sorted by grade, highest first.

**Requirements:**
- Use `dict.items()` and `sorted` with a key function.
- Compute and print the class average.
- Mark any student below 50 as failing.

**Done when:** the report is sorted, readable, and the average is correct.

---

## Exercise 4.5 — Sets

Given two lists of names, print:
- Names in both lists.
- Names in the first but not the second.
- All unique names across both.

Use sets, not loops.

**Done when:** the output is correct for lists with overlaps and duplicates.

---

## Exercise 4.6 — Comprehensions, or not

Write these two ways: once as a comprehension, once as a plain loop.

1. The squares of the even numbers from 0 to 20.
2. A dictionary mapping each word in a sentence to its length.

Then decide, for each, which version you would rather maintain, and write one sentence saying why.

**Done when:** you have a defensible opinion, not just a preference.
