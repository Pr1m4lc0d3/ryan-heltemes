﻿# Unit 10 — Where to go next

**Time:** ongoing
**Prerequisite:** Units 0–9

---

## The rule for this unit

**Go deep in one direction rather than wide in all of them.** You now have breadth — the fundamentals. What makes you useful is depth in something. Pick one of the directions below and go into it properly, rather than sampling all four.

---

## Direction 1 — Data

For working with numbers, tables, and analysis.

- **pandas** — dataframes, the workhorse of data work
- **numpy** — fast numerical arrays
- **matplotlib** — plotting
- **Jupyter** — interactive notebooks (now is the time; you have earned the file-and-run cycle)

Start by loading a CSV, cleaning it, computing summary statistics, and plotting a result. Real data is messy; the cleaning is most of the work.

---

## Direction 2 — Web

For building services and APIs.

- **HTTP** — learn the protocol before the framework
- **Flask** or **FastAPI** — web frameworks
- **SQL** and a database — SQLite to start, PostgreSQL later
- **Authentication** — sessions, tokens, and why "roll your own" is dangerous

Start by building a small API that stores and returns data from a database. Then add authentication. Then learn why you must never trust input from the network.

---

## Direction 3 — Automation

For making the computer do repetitive work.

- **Scripting** — file manipulation, batch processing
- **APIs** — `requests`, working with JSON responses
- **`subprocess`** — driving other programs
- **Scheduling** — cron, Task Scheduler, or a scheduler library

Start by automating something you actually do by hand. The best automation projects come from your own annoyance.

---

## Direction 4 — Systems

For understanding how programs really work.

- **Concurrency** — threads, processes, and when each is right
- **`asyncio`** — asynchronous I/O
- **Performance** — profiling, finding the slow part, and fixing only that
- **Packaging** — making your code installable and shareable

Start by profiling a slow program and making it faster. Measure first; never optimise on a hunch.

---

## What to keep doing, always

- **Read code.** Find a well-regarded open-source project in your chosen direction and read it. Not to copy — to see how people who are good at this structure things.
- **Write tests.** The habit does not stop being valuable.
- **Name things honestly.** The rule does not expire.
- **Keep functions small.** A function that does not fit on a screen does too much.
- **Choose structure over features.** A program's long-term behaviour is governed by its architecture, not its feature count.

---

## The habits that actually make you good

These are not in any unit. They are what separates people who can program from people who followed a course.

1. **Read more code than you write.** Especially code you did not write.
2. **Break things on purpose.** Feed your programs bad input and watch what happens.
3. **Read the traceback bottom-up.** The last line names the error.
4. **Type it yourself.** Never copy-paste while learning.
5. **When stuck, explain the problem out loud.** Half the time you will solve it mid-sentence.
6. **Ship something.** A finished small thing teaches more than an unfinished large one.

---

## A final note on what you have learned

If you have done the work through Unit 9, you know more than syntax. You know:

- That a name must tell the truth, or it is a defect.
- That a program must fail visibly, never silently.
- That a function is a boundary, and a class is a boundary.
- That "it worked once" is not evidence — a test is.
- That structure governs long-term behaviour, not feature count.

These are not Python facts. They are programming facts, and they transfer to every language you will ever use.

Go build something.
