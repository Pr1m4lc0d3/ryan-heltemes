﻿# Unit 5 — Reading assignment

**Read:** the `json` module from the standard library.

Find it:

```bash
python -c "import json; print(json.__file__)"
```

It is larger than `textwrap` — read the parts you use: `load`, `loads`, `dump`, `dumps`, and the exception classes.

---

## What to look for

1. **Where errors are raised.** Find `JSONDecodeError`. Where is it raised, and what information does it carry?

2. **What is caught and what is not.** Does the module catch exceptions internally? Does it let them propagate? Why?

3. **The public interface.** Which names are meant to be used, and which are internal? (Look for leading underscores.)

4. **The `__all__` list**, if present. What does it do, and why does the module define it?

---

## Questions to answer

1. What does `json.load` do, and what does it raise on bad input?
2. Find `JSONDecodeError`. What attributes does it have, and why?
3. Does the module catch errors silently anywhere? If so, is that the right choice?
4. How does the module signal that a document is malformed — a return value, or an exception? Why is that the right choice?
5. What did you learn about error handling that you will use?

---

## Why this module

`json` shows how a well-designed module handles failure: it raises specific, informative exceptions and lets the caller decide what to do. It never silently returns a wrong result. That is the standard for your own error handling — and reading a module that gets it right is the fastest way to internalise it.
