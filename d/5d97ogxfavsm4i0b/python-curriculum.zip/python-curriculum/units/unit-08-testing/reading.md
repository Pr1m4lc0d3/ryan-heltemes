﻿# Unit 8 — Reading assignment

**Read:** the tests of a small, well-regarded Python project. Good candidates:

- `pytest`'s own test suite — find it with `python -c "import pytest; print(pytest.__file__)"`
- Any small library you use, in its `tests/` folder
- The standard library's own test suite (large — pick one small module's tests)

---

## What to look for

1. **How tests are named.** Do the names describe the behaviour being tested, or just the function? Which is more useful when a test fails?

2. **What the happy path looks like.** How does a test set up its input and check its output?

3. **The edge cases.** Find a test for empty input, or zero, or a boundary value. How is it written?

4. **The error cases.** Find a test that checks an exception is raised. How is it written? (Look for `pytest.raises`.)

5. **Fixtures and setup.** Does the project use fixtures or helper functions to avoid repeating setup? How?

---

## Questions to answer

1. Pick three test names. Do they tell you what behaviour they check?
2. Find an edge-case test. What boundary does it cover?
3. Find a test that expects an exception. How is that expressed?
4. Is there any test you would call "unable to fail"? If not, why not?
5. What did you learn about testing that you will use?

---

## Why this assignment

Reading tests teaches you two things at once: how to write tests, and how the code under test is *supposed* to behave. A good test suite is a specification written in code. Learning to read it is learning to read the author's intent — and it is often clearer than the documentation.
