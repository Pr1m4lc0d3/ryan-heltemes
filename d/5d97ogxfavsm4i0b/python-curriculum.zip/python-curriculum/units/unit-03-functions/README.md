﻿# Unit 3 — Functions and structure

**Time:** 2 weeks
**Prerequisite:** Unit 2

---

## Why functions

So far your programs are scripts — a sequence of statements that run top to bottom. That works for small programs. It collapses for anything larger, because:

- The same logic gets copied and pasted, and the copies drift apart.
- You cannot test a piece of the program in isolation.
- You cannot name a piece of the program, so you cannot talk about it.

A **function** is a named block of code that does one thing. It is the primary unit of structure in programming.

---

## Defining and calling

```python
def greet(name):
    return f"Hello, {name}"

message = greet("Ada")
print(message)          # Hello, Ada
```

- `def` introduces the function.
- `greet` is its name.
- `name` is a **parameter** — a name for a value passed in.
- `return` sends a value back to the caller.
- `greet("Ada")` is a **call**; `"Ada"` is the **argument**.

---

## print vs return

This is the distinction beginners most often miss, and it causes real bugs.

- `print` **displays** a value. It sends nothing back to the caller.
- `return` **sends** a value back to the caller. It displays nothing.

```python
def add_print(a, b):
    print(a + b)

def add_return(a, b):
    return a + b

x = add_print(2, 3)     # prints 5, but x is None
y = add_return(2, 3)    # prints nothing, y is 5
```

A function that prints when it should return is broken for any caller who needs the value. A function that returns when it should print is usually fine but may confuse a user waiting for output. Decide which the function is *for*, and do that.

A function with no `return` statement returns `None`. That is a fact worth remembering: `x = add_print(2, 3)` sets `x` to `None`, not to `5`.

---

## Scope

Names defined inside a function are **local** — they exist only while the function runs.

```python
def f():
    x = 5       # local to f

f()
print(x)        # NameError: x is not defined
```

Names defined outside are **global** and readable inside functions:

```python
counter = 0

def show():
    print(counter)   # can read the global
```

But assigning to a global from inside a function requires the `global` keyword, and **you should almost never do it.** Global mutable state is a smell: it makes functions behave differently depending on hidden context, which makes them hard to test and reason about. Pass values in as arguments; return results out. Keep functions self-contained.

---

## Default and keyword arguments

Give a parameter a default:

```python
def greet(name, greeting="Hello"):
    return f"{greeting}, {name}"

greet("Ada")                    # Hello, Ada
greet("Ada", "Good morning")    # Good morning, Ada
greet("Ada", greeting="Hi")     # Hi, Ada
```

Calling with `name=value` is a **keyword argument**. It is clearer at the call site and lets you skip defaults.

**A trap:** never use a mutable default (`def f(items=[])`). The default list is created once and shared across all calls. This is a genuine bug source. Use `None` as the default and create the list inside:

```python
def f(items=None):
    if items is None:
        items = []
    ...
```

---

## Docstrings

A string literal as the first line of a function is its **docstring**:

```python
def area(width, height):
    """Return the area of a rectangle."""
    return width * height
```

It shows up in `help(area)` and in editors. Write one for any function whose purpose is not obvious from its name.

---

## Naming as correctness

**A function's name must describe what it does.** This is not a style preference — it is a correctness concern, because a misleading name causes the next reader to misunderstand the code.

```python
def get_user(id):
    user = db.fetch(id)
    db.delete(id)       # this function has a side effect its name hides
    return user
```

The name says "get". The function also deletes. A caller who trusts the name will destroy data. The name is a lie, and the lie is the defect — as serious as a logic error.

Rules:

- A function should do **one thing**, and its name should say exactly that thing.
- If you cannot name it precisely, it is doing too much — split it.
- Prefer verbs for functions (`calculate_total`, `load_config`) and nouns for values (`total`, `config`).

---

## Structural idea for this unit

**A function is a boundary.** It takes inputs, produces an output, and hides how. A caller should be able to use it without reading its body. If a caller must know the internals to use it correctly, the boundary has failed.

---

## Deliverable

Refactor your prime checker and Fibonacci program from Unit 2 into functions, then write a program that uses both. See `exercises.md`.
