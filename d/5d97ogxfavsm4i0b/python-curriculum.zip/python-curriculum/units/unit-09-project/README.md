﻿# Unit 9 — Real project

**Time:** 4 weeks
**Prerequisite:** Units 0–8

---

## What this unit is

One program, built end to end. Not a toy, not an exercise — a real piece of software with structure, error handling, tests, and documentation.

The project is chosen for **difficulty**, not usefulness. You are learning programming as a discipline; the point is to confront hard problems — state, parsing, edge cases — not to build something you happen to need. A tool you will never use again is fine if it forces you to think.

---

## Requirements for any project

Whatever you build, it must:

1. **Run from a clean checkout.** Someone who downloads your folder can run it by following the README. No hidden steps.
2. **Have a README** explaining what it is, how to install dependencies, and how to run it.
3. **Have tests** that pass.
4. **Fail visibly on bad input** — no silent wrong answers.
5. **Have names that tell the truth.** Every function, variable, and file.
6. **Be structured** — split into modules by responsibility, not one giant file.

---

## Choose one

Full briefs are in `projects/`. Summaries:

### Option A — A small interpreter

Write an interpreter for a tiny language: numbers, arithmetic, variables, and `print`. You will build a tokenizer, a parser, and an evaluator.

**Why it is hard:** you must handle precedence, nesting, and malformed input. It touches every concept in the course.

### Option B — A text-adventure engine

Build an engine that loads a world from a data file (rooms, exits, items) and lets a player move around and interact.

**Why it is hard:** state management, parsing commands, and designing a data format that is expressive without being complex.

### Option C — A `grep` clone

Write a program that searches files for a pattern and prints matching lines, with options for case-insensitivity, line numbers, and recursion.

**Why it is hard:** regular expressions, walking a directory tree, handling binary files and permissions, and matching the behaviour of a real tool.

### Option D — Your own

Propose something with comparable difficulty. It must have a clear input, a clear output, and at least one genuinely hard part. Get it approved before starting.

---

## How to build it

Do not write the whole thing and then test it. Work in slices:

1. **Design first.** Write a short document: what it does, what the modules are, what the interfaces between them are. One page.
2. **Build the smallest version that runs.** Even if it only handles one case. Get it running.
3. **Add one feature at a time.** Test after each.
4. **Refactor as you go.** When a file gets too big or a function does too much, fix it then, not later.

---

## Structural idea for this unit

**Architecture over accumulation.** A program's long-term behaviour is governed by its structure, not by how many features it has. A thousand features piled on a bad structure is a program that cannot be changed without breaking. Ten features on a good structure is a program that can grow.

The measure of this project is not how much it does. It is whether someone else could read it, understand it, and extend it without fear.

---

## Deliverable

The project, in a folder, with a README and passing tests. See `projects/` for the full briefs.
