﻿# Unit 4 — Reading assignment

**Read:** the `collections` module from the standard library — specifically `Counter` and `defaultdict`.

Find it:

```bash
python -c "import collections; print(collections.__file__)"
```

Read the class definitions and the docstrings. You do not need to understand every line of the C-level optimisations — read the Python-level structure.

---

## What to look for

1. **How `Counter` is a dictionary with extra behaviour.** What does it add on top of a plain dict?

2. **`most_common`.** How does it work? What does it return?

3. **`defaultdict`.** What problem does it solve? What happens when you access a missing key?

4. **The relationship to built-ins.** `Counter` subclasses `dict`. What does it inherit, and what does it override?

---

## Questions to answer

1. What does `Counter` do that a plain dict does not?
2. What does `defaultdict(int)` give you that a plain dict does not? Show an example.
3. Why is `Counter` a subclass of `dict` rather than a standalone class?
4. Rewrite your word-frequency counter from Exercise 4.3 using `Counter`. How much shorter is it?
5. What did you learn about collections that you will use?

---

## Why this module

`collections` shows how the standard library builds convenient tools on top of the basic data structures. `Counter` is exactly the tool your word-frequency exercise needed — and discovering that the standard library already has it is the lesson: before you write it, check whether it exists.
