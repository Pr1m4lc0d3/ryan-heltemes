﻿# Unit 5 — Files and errors

**Time:** 2 weeks
**Prerequisite:** Unit 4

---

## Why this unit matters most

Everything so far has been in memory — the program runs, and its data vanishes. This unit is where programs touch the outside world, and where they meet the fact that the outside world fails: files are missing, disks are full, input is malformed. How a program behaves when things go wrong is the difference between a toy and a tool.

---

## Reading and writing files

```python
with open("notes.txt", "r") as f:
    content = f.read()
```

The `with` statement is not optional decoration. It guarantees the file is **closed** when the block ends — even if an error occurs inside it. Without `with`:

```python
f = open("notes.txt")
content = f.read()
f.close()          # never runs if read() raises
```

The file stays open, leaking a resource. Always use `with`.

Modes:

- `"r"` — read (default). Fails if the file does not exist.
- `"w"` — write. **Truncates the file to empty** if it exists. Dangerous.
- `"a"` — append. Adds to the end.
- `"x"` — create. Fails if the file already exists.

Reading line by line:

```python
with open("notes.txt") as f:
    for line in f:
        print(line.rstrip())    # rstrip removes the trailing newline
```

Writing:

```python
with open("out.txt", "w") as f:
    f.write("hello\n")
    f.write("world\n")
```

---

## Paths

Use `pathlib`, not string concatenation:

```python
from pathlib import Path

p = Path("data") / "notes.txt"   # joins correctly on every OS
p.exists()
p.read_text()
p.write_text("hello")
```

`Path` handles the difference between Windows (`\`) and Unix (`/`) separators for you. String paths break across platforms; `Path` does not.

---

## CSV and JSON

The two formats you will meet constantly. Both have standard-library support — never parse them by hand.

**JSON:**

```python
import json

data = {"name": "Ada", "age": 36}
with open("data.json", "w") as f:
    json.dump(data, f, indent=2)

with open("data.json") as f:
    loaded = json.load(f)
```

**CSV:**

```python
import csv

with open("people.csv", newline="") as f:
    reader = csv.DictReader(f)
    for row in reader:
        print(row["name"])
```

`newline=""` is required on Windows to avoid doubled line endings. Always include it.

---

## Exceptions

When something goes wrong, Python **raises an exception**. If nothing handles it, the program stops and prints a traceback.

```python
try:
    number = int(user_input)
except ValueError:
    print("That is not a number.")
```

- `try` — the code that might fail.
- `except ValueError` — what to do if that specific error occurs.

**Catch specific exceptions.** This is a rule, not a suggestion:

```python
try:
    ...
except:              # BAD — catches everything, including Ctrl+C and bugs
    pass
```

A bare `except:` swallows *every* error, including ones you did not anticipate and ones you would want to know about. It also hides bugs: a typo in your code raises a `NameError`, which the bare except eats silently, and you spend an hour wondering why nothing happens.

Catch what you expect:

```python
try:
    number = int(user_input)
except ValueError:
    print("That is not a number.")
```

You can handle several, and add `else` and `finally`:

```python
try:
    f = open("data.txt")
except FileNotFoundError:
    print("No data file found.")
else:
    print("Opened fine.")
    f.close()
finally:
    print("Done.")      # runs whether or not an error occurred
```

---

## Raising exceptions

You can raise your own:

```python
def withdraw(balance, amount):
    if amount > balance:
        raise ValueError("insufficient funds")
    return balance - amount
```

Raising is how a function says "I cannot do what was asked." It is better than returning a sentinel value like `-1` or `None`, because a sentinel can be ignored by accident. An exception cannot be ignored — it stops the program unless someone handles it deliberately.

---

## Safe failure

This is the structural idea of the unit, and it is a rule you will carry for the rest of your programming life.

**A program should fail in a contained, visible way — never silently, never catastrophically.**

Three failure modes, in order of preference:

1. **Fail visibly and safely.** The program reports the problem clearly and stops or recovers. This is correct.
2. **Fail silently.** The program continues as if nothing happened, producing wrong results. This is a defect — often a dangerous one, because nobody knows the output is wrong.
3. **Fail catastrophically.** The program corrupts data, deletes files, or crashes the system. This is the worst.

A program that crashes with a clear message is *better* than one that silently produces wrong answers. "It didn't crash" is not the same as "it worked."

The rule for error handling: **if your program cannot do what was asked, it must say so.** Never swallow an error and pretend.

---

## Deliverable

A to-do list that persists to a JSON file between runs, and does not lose data if the file is corrupt. See `exercises.md`.
