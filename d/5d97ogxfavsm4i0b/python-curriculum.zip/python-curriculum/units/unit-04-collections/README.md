﻿# Unit 4 — Collections

**Time:** 2 weeks
**Prerequisite:** Unit 3

---

## Why collections

Real programs handle more than one value. Collections are how you group values and operate on them as a unit. Python has four you will use constantly: list, tuple, dict, set.

---

## Lists

An ordered, changeable sequence:

```python
fruits = ["apple", "banana", "cherry"]

fruits[0]           # "apple" — indexing starts at 0
fruits[-1]          # "cherry" — negative indexes from the end
fruits[1:3]         # ["banana", "cherry"] — slicing, end excluded
fruits.append("date")
fruits.remove("apple")
len(fruits)         # 4
"banana" in fruits  # True
```

**Slicing:** `fruits[1:3]` gives elements at index 1 and 2 — the end index is **excluded**. `fruits[:2]` takes the first two. `fruits[2:]` takes from index 2 to the end. `fruits[:]` copies the whole list.

Iterate:

```python
for fruit in fruits:
    print(fruit)
```

If you need the index too:

```python
for i, fruit in enumerate(fruits):
    print(i, fruit)
```

---

## Tuples

An ordered, **unchangeable** sequence:

```python
point = (3, 4)
x, y = point        # unpacking
```

Tuples are for values that belong together and should not change — coordinates, a date, a returned pair. The immutability is the point: it guarantees the value cannot be altered after creation.

A function returning multiple values actually returns a tuple:

```python
def min_max(numbers):
    return min(numbers), max(numbers)

low, high = min_max([3, 1, 4, 1, 5])
```

---

## Dictionaries

A mapping from keys to values — the workhorse data structure:

```python
ages = {"ada": 36, "alan": 41}

ages["ada"]             # 36
ages["grace"] = 45      # add a new key
"ada" in ages           # True
ages.get("nobody")      # None — safe lookup
ages.get("nobody", 0)   # 0 — with a default
```

**`ages["nobody"]` raises a `KeyError`; `ages.get("nobody")` returns `None`.** Use `.get()` when the key might be absent and you have a sensible fallback.

Iterate:

```python
for name, age in ages.items():
    print(name, age)

for name in ages.keys():
    ...

for age in ages.values():
    ...
```

Dicts preserve insertion order (Python 3.7+).

---

## Sets

An unordered collection of unique values:

```python
tags = {"python", "code", "python"}    # {"python", "code"} — duplicates removed
"python" in tags                        # True — fast membership test

a = {1, 2, 3}
b = {3, 4, 5}
a | b    # union: {1, 2, 3, 4, 5}
a & b    # intersection: {3}
a - b    # difference: {1, 2}
```

Use a set when you need uniqueness or fast membership testing. Checking `x in list` scans the whole list; `x in set` is effectively instant regardless of size.

---

## Comprehensions

A compact way to build a collection from another:

```python
squares = [n * n for n in range(10)]

evens = [n for n in range(20) if n % 2 == 0]

lengths = {word: len(word) for word in ["hi", "hello"]}
```

**When to use a loop instead:** if the comprehension needs more than one condition, or an `if`/`else`, or is hard to read in one line — write the loop. A comprehension that takes ten seconds to parse is worse than a five-line loop. Readability beats cleverness.

---

## Mutability and aliasing — the big one

Lists and dicts are **mutable**. This has a consequence that surprises nearly everyone:

```python
a = [1, 2, 3]
b = a           # b is NOT a copy — b and a are the same list
b.append(4)
print(a)        # [1, 2, 3, 4]  ← a changed too!
```

`b = a` binds a second name to the **same object**. To actually copy:

```python
b = a.copy()        # shallow copy
b = a[:]            # also a shallow copy
import copy
b = copy.deepcopy(a)  # deep copy — copies nested objects too
```

The same trap applies to passing a list to a function:

```python
def add_item(items):
    items.append("x")       # mutates the caller's list

my_list = []
add_item(my_list)
print(my_list)              # ["x"] — the caller's list was changed
```

This is not a bug in Python — it is how references work. The bug is forgetting it. When you pass a mutable object to a function, decide: does this function *change* the object, or *use* it? If it changes it, the name should say so (`add_item`, `sort_in_place`), because a function that mutates its argument without saying so is a defect.

---

## Structural idea for this unit

**Two names can refer to one object.** Every time you assign a list or dict to another name, or pass it to a function, ask whether you mean to share it or copy it. Getting this wrong is the source of a whole class of bugs that are hard to find because the change happens somewhere other than where you looked.

---

## Deliverable

A word-frequency counter, a statistics program, and a grade report. See `exercises.md`.
