﻿# Unit 1 — Exercises

---

## Exercise 1.1 — Greeting

Write a program that asks for the user's name and prints a greeting using an f-string.

**Done when:** entering `Ada` prints something like `Hello, Ada!`.

---

## Exercise 1.2 — Age calculator

Ask for a name and a birth year. Print the person's age.

**Requirements:**
- The birth year arrives from `input()` as text. Convert it to an integer.
- Use an f-string for the output.
- Use the current year as a literal for now (we will not touch dates until Unit 6).

**Done when:** entering `Ada` and `1988` prints the correct age.

---

## Exercise 1.3 — Break the conversion

Run your age calculator and enter `nineteen` as the birth year. Read the traceback.

- What error type is it?
- What line does it name?
- In your own words, what is the program telling you?

Do not fix it yet. Just read it. (Fixing it is Unit 5's job.)

---

## Exercise 1.4 — Arithmetic

Write a program that asks for two numbers and prints their sum, difference, product, quotient, and remainder.

**Requirements:**
- Convert both inputs to floats.
- Label each result clearly.
- Check what `10 / 3` and `10 // 3` and `10 % 3` each produce, and make sure your output matches what you expect.

**Done when:** entering `10` and `3` gives the results you predicted before running.

---

## Exercise 1.5 — Name the values honestly

Here is a program. Its names are bad. Rewrite it with names that tell the truth, and add a comment only where a *why* needs explaining.

```python
a = input("? ")
b = input("? ")
c = float(a) + float(b)
print(c)
```

**Done when:** someone reading your version can tell what it does without running it.

---

## Exercise 1.6 — Temperature converter

Ask for a temperature in Celsius and print it in Fahrenheit. Then do the reverse in a second program.

Formula: `F = C * 9/5 + 32`

**Done when:** `100` Celsius prints `212.0` Fahrenheit, and `212` Fahrenheit prints `100.0` Celsius.

**Think about:** what happens if the user enters `-40`? What should happen if they enter text?
