﻿# Unit 5 — Exercises

---

## Exercise 5.1 — Read a file

Create a text file with several lines. Write a program that reads it and prints each line with its line number.

**Requirements:**
- Use `with open(...)`.
- Strip the trailing newline from each line.
- Handle the case where the file does not exist — print a clear message, do not crash.

**Done when:** a missing file produces a friendly message, not a traceback.

---

## Exercise 5.2 — Write and append

Write a program that appends a timestamped line to a log file each time it runs.

**Requirements:**
- Use append mode (`"a"`), so previous lines are not lost.
- Use `datetime` for the timestamp.
- Run it three times and confirm all three lines are present.

**Done when:** the log grows with each run.

---

## Exercise 5.3 — JSON round-trip

Write a dictionary to a JSON file, then read it back and print it.

**Requirements:**
- Use `json.dump` and `json.load`.
- Use `indent=2` so the file is human-readable.
- Confirm the value read back equals the value written.

**Done when:** the file on disk is readable and the round-trip is lossless.

---

## Exercise 5.4 — The persistent to-do list

The main deliverable for this unit.

Build a to-do list that stores its items in a JSON file and loads them on startup.

**Requirements:**
- On start, load existing items from `todos.json`. If the file does not exist, start with an empty list.
- Let the user add items, list them, and mark them done.
- Save after every change, so nothing is lost if the program is closed.
- **If the file is corrupt** (invalid JSON), do not crash and do not silently discard the data. Decide what it does instead, and write the reason as a comment. A reasonable choice: rename the corrupt file to `todos.json.bak`, warn the user, and start fresh — so the data is preserved for inspection.

**Done when:** you can add items, close the program, reopen it, and see them. Then corrupt the file by hand, run the program, and confirm it behaves as you decided.

---

## Exercise 5.5 — Catch specifically

Below is a program with a bare `except`. Explain what is wrong with it, then rewrite it to catch only what it should.

```python
try:
    number = int(input("Number: "))
    result = 100 / number
    print(result)
except:
    print("Something went wrong")
```

**Requirements:**
- Catch `ValueError` (bad number) and `ZeroDivisionError` (division by zero) with distinct, clear messages.
- Do not catch anything else.

**Done when:** entering `abc` and entering `0` produce different, correct messages.

---

## Exercise 5.6 — Fail safe

Write a function `load_config(path)` that reads a JSON config file and returns a dictionary.

**Requirements:**
- If the file is missing, raise a clear, named exception — do not return an empty dict silently.
- If the file is present but not valid JSON, raise a clear exception naming the file.
- Document in the docstring what it raises and why.

**Think about:** why is returning `{}` on a missing file worse than raising? Write your answer in one sentence.
