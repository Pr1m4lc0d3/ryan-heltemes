﻿# Unit 8 — Testing

**Time:** 1 week
**Prerequisite:** Unit 7

---

## Why testing

"It worked on my machine" is not evidence. It means you ran it once, on one input, and it did not crash. That tells you almost nothing about whether it is correct.

A **test** is a piece of code that checks another piece of code and reports whether it behaved as expected. Tests are how you know your program works — not hope, not a single manual run, but a repeatable check you can run any time.

---

## assert

The simplest test is an assertion:

```python
def add(a, b):
    return a + b

assert add(2, 3) == 5
assert add(-1, 1) == 0
assert add(0, 0) == 0
```

If the condition is true, nothing happens. If it is false, Python raises `AssertionError` and stops. That is the point: a failing test is loud.

---

## pytest

`pytest` is the standard testing tool. Install it in your virtual environment:

```bash
pip install pytest
```

Write tests in a file named `test_*.py`:

```python
# test_math_utils.py
from math_utils import add, is_prime

def test_add_positive():
    assert add(2, 3) == 5

def test_add_negative():
    assert add(-1, 1) == 0

def test_is_prime_true():
    assert is_prime(7) is True

def test_is_prime_false():
    assert is_prime(9) is False

def test_is_prime_edge_cases():
    assert is_prime(0) is False
    assert is_prime(1) is False
    assert is_prime(-5) is False
```

Run them:

```bash
pytest
```

`pytest` finds files named `test_*.py`, runs every function named `test_*`, and reports pass or fail. A failing test shows you exactly which assertion failed and what the actual value was.

---

## Test the edges

The interesting bugs live at the boundaries. For every function, ask:

- What if the input is empty?
- What if it is zero?
- What if it is negative?
- What if it is enormous?
- What if it is the wrong type?
- What if two inputs are equal?

A test suite that only checks the happy path is barely better than no tests, because it will pass while the program is wrong.

```python
def test_mean_empty():
    assert mean([]) is None

def test_mean_single():
    assert mean([5]) == 5

def test_mean_negative():
    assert mean([-1, -2, -3]) == -2
```

---

## A test that cannot fail

This is worse than no test, because it gives false confidence:

```python
def test_add():
    result = add(2, 3)
    assert result == result        # always true — tests nothing
```

Or a test that catches its own failure:

```python
def test_add():
    try:
        assert add(2, 3) == 5
    except AssertionError:
        pass                        # swallows the failure
```

A test must be able to fail. If you cannot imagine an input that would make it fail, it is not testing anything. Before trusting a test, deliberately break the code it tests and confirm the test goes red. A test that stays green when the code is broken is a defect.

---

## What to test

- Every function's normal case.
- Every function's edge cases.
- Every branch of an `if`/`else`.
- Every error path — does it raise the right exception?

You do not need 100% coverage. You need the tests that would catch a real mistake.

---

## Structural idea for this unit

**A passing test is evidence; a manual run is not.** This is where you stop hoping and start knowing. The habit of writing a test alongside the code also changes how you write the code — functions that are easy to test are functions with clear inputs, clear outputs, and no hidden state. Testability is a design property, not an afterthought.

---

## Deliverable

Test suites for the prime checker, the statistics functions, and the to-do tool. See `exercises.md`.
