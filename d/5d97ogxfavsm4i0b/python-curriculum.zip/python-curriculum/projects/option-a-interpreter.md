﻿# Project Brief — A Small Interpreter

**Difficulty:** high
**Time:** 4 weeks

---

## What you build

An interpreter for a tiny programming language. It reads source text and executes it.

The language supports:

- Integer and float literals: `42`, `3.14`
- Arithmetic: `+`, `-`, `*`, `/`, with parentheses and correct precedence
- Variables: `x = 5`, then `x * 2`
- Printing: `print x + 1`

Example program:

```
x = 10
y = x * 2 + 3
print y
print (x + y) / 2
```

Expected output:

```
23
16.5
```

---

## Why this is the hardest option

You must build three things in sequence, and each depends on the last:

1. **A tokenizer** — turns the source text into a list of tokens (`NUMBER(10)`, `ASSIGN`, `NUMBER(5)`).
2. **A parser** — turns the tokens into a tree that captures precedence: `2 + 3 * 4` becomes `Add(2, Multiply(3, 4))`, not `Multiply(Add(2, 3), 4)`.
3. **An evaluator** — walks the tree and computes the result.

This touches every concept in the course: functions, collections, classes, error handling, and testing.

---

## Structure

Suggested modules (name them what they are):

```
interpreter/
├── tokenizer.py     # text -> tokens
├── parser.py        # tokens -> tree
├── evaluator.py     # tree -> result
├── errors.py        # your own exception types
├── main.py          # reads a file, runs it
└── tests/
    ├── test_tokenizer.py
    ├── test_parser.py
    └── test_evaluator.py
```

Each module has one job and a name that says what it is.

---

## Requirements

- **Precedence is correct.** `2 + 3 * 4` is 14, not 20.
- **Parentheses work.** `(2 + 3) * 4` is 20.
- **Malformed input fails clearly.** `x = = 5` or `2 +` must raise a named error with a message that says what was wrong and where.
- **Undefined variables fail clearly.** `print z` when `z` was never assigned must say so.
- **Division by zero fails clearly.**
- **Tests for each module**, including the error cases.
- **A README** explaining the language's syntax and how to run it.

---

## Build order

1. **Tokenizer first.** Write it, test it in isolation. Feed it strings, check the tokens.
2. **Parser next.** Test it on expressions with known precedence.
3. **Evaluator last.** Test it on trees you build by hand, then on parsed programs.
4. **Wire it together** in `main.py`.
5. **Add error handling** — go back and make every failure path clear.

Do not try to build all three before testing any. Each layer should be correct before the next is built on it.

---

## What "done" looks like

- The example program above produces the expected output.
- Every error case produces a clear message, not a traceback.
- The tests pass.
- Someone else can read the README and run a program.

---

## Stretch goals

- String literals and concatenation.
- `if` statements and comparison operators.
- A REPL — read a line, evaluate it, print the result, repeat.
- Comments in the language.
