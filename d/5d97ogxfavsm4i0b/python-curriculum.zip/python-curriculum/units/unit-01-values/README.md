﻿# Unit 1 — Values, names, and output

**Time:** 1 week
**Prerequisite:** Unit 0

---

## The smallest complete program

A program is data, a name for that data, and a way to see it. This unit covers all three.

---

## Values and types

Python has a small set of built-in types you will use constantly:

```python
42          # int — a whole number
3.14        # float — a number with a decimal point
"hello"     # str — text
True        # bool — true or false
None        # the absence of a value
```

You can check any value's type:

```python
type(42)        # <class 'int'>
type(3.14)      # <class 'float'>
type("hello")   # <class 'str'>
```

Integers and floats are different, and Python treats them differently. `10 / 3` gives `3.333...` (a float, because `/` always produces a float). `10 // 3` gives `3` (floor division, an int). `10 % 3` gives `1` (the remainder).

---

## Variables are names, not containers

This is the most important idea in the unit.

```python
x = 5
```

Read that as: **the name `x` is bound to the value `5`.** Not "the box `x` contains 5". The distinction matters because a name can be rebound:

```python
x = 5
x = "now I'm a string"
```

The name `x` now refers to a string. Nothing was "overwritten" in a container — the name was simply pointed at a different value.

This will seem pedantic now. In Unit 4, when you meet lists, it will save you from a whole class of confusing bugs, because two names can refer to the *same* mutable object.

---

## Output: print and f-strings

`print()` writes to the screen:

```python
print("hello")
print(42)
print("the answer is", 42)
```

**f-strings** embed values inside text. Put an `f` before the quote and wrap expressions in `{}`:

```python
name = "Ada"
age = 36
print(f"{name} is {age} years old")
```

Output: `Ada is 36 years old`

f-strings are the modern, readable way to build strings. Use them.

---

## Input

`input()` reads a line of text from the user:

```python
name = input("What is your name? ")
print(f"Hello, {name}")
```

**Critical:** `input()` **always returns a string.** Even if the user types `42`, you get the string `"42"`, not the number `42`. You must convert it:

```python
age_text = input("How old are you? ")   # "42"
age = int(age_text)                      # 42
```

Forgetting this is one of the most common beginner bugs. `"42" + 1` raises a `TypeError`; `42 + 1` gives `43`.

---

## Type conversion

Convert between types explicitly:

```python
int("42")      # 42
float("3.14")  # 3.14
str(42)        # "42"
bool(0)        # False
bool(1)        # True
bool("")       # False — empty string is falsy
bool("hi")     # True
```

Conversion can fail. `int("hello")` raises a `ValueError`. That is correct behaviour — the program says it cannot do what was asked rather than guessing. In Unit 5 you will learn to handle such failures deliberately.

---

## Comments

A comment starts with `#`:

```python
# This is a comment
x = 5  # This one explains the line
```

Comments should explain **why**, not **what**. This is noise:

```python
x = x + 1  # add one to x
```

This is useful:

```python
x = x + 1  # offset by one: the API is 1-indexed, we are 0-indexed
```

If the code needs a comment to say what it does, the code is unclear — fix the code. If it needs a comment to say why, the comment earns its place.

---

## Structural idea for this unit

**A name should tell the truth about the value it holds.** `age` is a good name for a number of years. `data` or `x` is not. The name is the first thing a reader sees; a misleading name is a defect, not a style preference.

---

## Deliverable

An age calculator: ask for a name and a birth year, print the person's age. Then make it handle the case where the birth year is entered as text — which, since `input()` always returns text, means converting it explicitly.

Proceed to `exercises.md`.
