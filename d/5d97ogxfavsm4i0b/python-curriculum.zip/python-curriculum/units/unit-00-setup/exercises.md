﻿# Unit 0 — Exercises

---

## Exercise 0.1 — Hello, world

Create a file `hello.py` that prints a greeting of your choice. Run it from the terminal.

**Done when:** the terminal shows your greeting.

---

## Exercise 0.2 — Break it on purpose

Edit `hello.py` so it fails. Do each of these in turn, run the file, and read the traceback:

1. Print a variable that does not exist.
2. Remove the closing quote from the string.
3. Misspell `print` as `prnt`.

For each, write down:
- The error type (the word before the colon on the last line).
- The line number the traceback names.
- What the message is telling you.

**Done when:** you can predict, before running, roughly what each error will say.

---

## Exercise 0.3 — Navigate

From the terminal:

1. Make a folder called `practice`.
2. Enter it.
3. Make a folder inside it called `notes`.
4. Enter `notes`, then go back up to `practice`.
5. Print the current directory.

**Done when:** you can move around the filesystem without looking up the commands.

---

## Exercise 0.4 — Two files

Create a second file `greet.py` in the same folder that prints a different message. Run each file separately. Then run them in sequence from the same terminal.

**Done when:** you understand that each `.py` file is a separate program you choose to run.
