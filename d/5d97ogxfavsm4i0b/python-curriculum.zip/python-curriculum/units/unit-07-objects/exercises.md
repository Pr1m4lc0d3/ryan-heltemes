﻿# Unit 7 — Exercises

---

## Exercise 7.1 — A class with a boundary

Write a `BankAccount` class.

**Requirements:**
- `__init__(self, owner, balance=0)`
- `deposit(amount)` — rejects negative or zero amounts with a clear error.
- `withdraw(amount)` — refuses to overdraw; raises a clear error if it would.
- `balance` is readable but must not be settable directly from outside — use a leading underscore and a property, or a read-only method.
- `__repr__` showing the owner and balance.

**Done when:** you cannot put the account into an invalid state from outside the class.

**Think about:** why is `account.balance = -100` a defect, even if it "works"?

---

## Exercise 7.2 — Card and Deck

Write a `Card` class and a `Deck` class.

**Requirements:**
- `Card` has a rank and a suit, with a readable `__repr__` (e.g. `Ace of Spades`).
- `Deck` builds all 52 cards in `__init__`.
- `Deck.shuffle()` shuffles in place.
- `Deck.deal()` removes and returns the top card. Dealing from an empty deck must raise a clear error, not return `None`.
- `Deck.__len__` so `len(deck)` works.

**Done when:** a fresh deck has 52 cards, dealing reduces it by one, and dealing 53 times raises an error.

---

## Exercise 7.3 — A simple card game

Extend 7.2 into a game: two players draw a card each; the higher card wins the round. Play 10 rounds and report the score.

**Requirements:**
- Rank order: 2 low, Ace high.
- Handle a tie.
- The game logic is separate from the `Card` and `Deck` classes — those must not know about the game.

**Done when:** the game runs and produces a sensible score.

**Think about:** why should `Deck` not contain the game rules?

---

## Exercise 7.4 — Composition, not inheritance

Here is an inheritance mistake. Rewrite it using composition, and explain what the original gets wrong.

```python
class Stack(list):
    def push(self, item):
        self.append(item)
```

**Done when:** your `Stack` has a list *inside* it, not as a parent, and does not expose list methods that break stack discipline.

**Think about:** what does `Stack.pop(0)` do in the original? Should a stack allow that?

---

## Exercise 7.5 — Should this be a class?

For each of these, decide whether a class is warranted. Write one sentence of justification.

1. A function that converts Celsius to Fahrenheit.
2. A shopping cart holding items with prices, with methods to add, remove, and total.
3. A function that reads a JSON file.
4. A connection to a database that must be opened, used, and closed.
5. A set of three string-cleaning functions that share no state.

**Done when:** you can defend each decision by naming what the class would *own*.
