﻿# Unit 6 — Reading assignment

**Read:** the `argparse` module from the standard library — specifically the `ArgumentParser` class and how `add_argument` works.

Find it:

```bash
python -c "import argparse; print(argparse.__file__)"
```

---

## What to look for

1. **How `add_argument` records information.** What does it store, and how does `parse_args` use it?

2. **`action="store_true"`.** Find where actions are handled. What does this action do differently from the default?

3. **Error handling.** What happens when an argument is missing or invalid? Does `argparse` raise, or print and exit? Why is that the right choice for a command-line tool?

4. **Help generation.** Where does the `--help` text come from? How does the parser build it from the argument definitions?

---

## Questions to answer

1. What does `add_argument` do, in one sentence?
2. What does `action="store_true"` produce when the flag is absent? When present?
3. When a required argument is missing, what does `argparse` do — raise an exception, or exit the program? Why?
4. How does `argparse` know what to print for `--help`?
5. What did you learn about designing a user-facing interface that you will use?

---

## Why this module

`argparse` is the standard for command-line interfaces in Python, and it shows how a library can be both powerful and easy to use. It also demonstrates a deliberate design choice: a command-line tool that exits with a clear message on bad input, rather than raising an exception the user cannot act on. That is safe failure at the interface level.
